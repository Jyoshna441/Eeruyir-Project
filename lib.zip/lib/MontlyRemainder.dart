import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/uril.dart';

class MonthlyRemainder extends StatefulWidget {
  final String patientId;
  final int months;

  const MonthlyRemainder(
      {super.key, required this.patientId, required this.months});

  @override
  _MonthlyRemainderState createState() => _MonthlyRemainderState();
}

class _MonthlyRemainderState extends State<MonthlyRemainder> {
  Map<String, dynamic> alert = {
    'alert_message': '',
    'tests_required': '',
    'scan_required': '',
    'is_acknowledged': 0,
  };
  bool loading = true;
  String error = '';

  @override
  void initState() {
    super.initState();
    fetchAlert();
  }

  Future<void> fetchAlert() async {
    setState(() {
      loading = true;
    });
    try {
      print(
          'Sending: patient_id: ${widget.patientId}, month: ${widget.months}');
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/get_alert.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(
            {'patient_id': widget.patientId, 'month': widget.months}),
      );
      print('Response Status: ${response.statusCode}');

      if (response.statusCode != 200) {
        throw Exception('HTTP error! status: ${response.statusCode}');
      }

      final jsonResponse = jsonDecode(response.body);
      print('Server Response: $jsonResponse');

      if (jsonResponse['error'] != null) {
        setState(() {
          error = jsonResponse['error'];
        });
      } else {
        setState(() {
          alert = jsonResponse;
        });
      }
    } catch (e) {
      setState(() {
        error = 'An error occurred while fetching the alert: $e';
      });
      print('Fetch error: $e');
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> acknowledgeAlert() async {
    try {
      print(
          'Acknowledging Alert for: patient_id: ${widget.patientId}, month: ${widget.months}');
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/acknowledge_alert.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(
            {'patient_id': widget.patientId, 'month': widget.months}),
      );
      final jsonResponse = jsonDecode(response.body);
      print('Acknowledgment Response: $jsonResponse');

      if (jsonResponse['success'] != null) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Success'),
            content: const Text('Alert acknowledged successfully!'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('OK')),
            ],
          ),
        );
        fetchAlert(); // Fetch the updated alert state
      } else {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Error'),
            content: Text(jsonResponse['error'] ?? 'Something went wrong.'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('OK')),
            ],
          ),
        );
      }
    } catch (e) {
      print('Error acknowledging alert: $e');
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Error'),
          content: const Text('Failed to acknowledge the alert.'),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('OK')),
          ],
        ),
      );
    }
  }

  void handleAlertClick() {
    if (alert['is_acknowledged'] == 1) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Alert'),
          content: const Text('This alert has already been acknowledged.'),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('OK')),
          ],
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Alert'),
          content: Text(alert['alert_message']),
          actions: [
            TextButton(onPressed: acknowledgeAlert, child: const Text('OK')),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Monthly Reminder'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context)
                .pop(); // This will navigate back to the previous screen
          },
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: error.isNotEmpty
              ? Text(error,
                  style: const TextStyle(fontSize: 18, color: Colors.red))
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(alert['alert_message'],
                        style: const TextStyle(fontSize: 18)),
                    const SizedBox(height: 10),
                    Text('Tests Required: ${alert['tests_required']}',
                        style: const TextStyle(fontSize: 18)),
                    const SizedBox(height: 10),
                    Text('Scan Required: ${alert['scan_required']}',
                        style: const TextStyle(fontSize: 18)),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: handleAlertClick,
                      child: const Text('Show Alert'),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
