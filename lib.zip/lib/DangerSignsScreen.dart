import 'package:flutter/material.dart';

class DangerSignsScreen extends StatelessWidget {
  final List<Map<String, dynamic>> dangerSigns = [
    {
      'id': '1',
      'image': 'assets/Dangersigns/p_1.jpeg',
      'description': 'Severe Pain in Abdomen',
    },
    {
      'id': '2',
      'image': 'assets/Dangersigns/p_4.png',
      'description':
          'Weakness and breathlessness',
    },
    {
      'id': '3',
      'image': 'assets/Dangersigns/p3.png',
      'description': 'Bleeding per Vaginum',
    },
    {
      'id': '4',
      'image': 'assets/Dangersigns/p4.jpeg',
      'description': 'Excessive Swelling in Legs',
    },
    {
      'id': '5',
      'image': 'assets/Dangersigns/p_5.png',
      'description': 'Convulsions',
    },
    {
      'id': '6',
      'image': 'assets/Dangersigns/p6.png',
      'description': 'High Fever',
    },
  ];

  DangerSignsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Danger Signs',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold,color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),

      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 1,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: dangerSigns.length,
                itemBuilder: (context, index) {
                  return Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset(
                              dangerSigns[index]['image'],
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            dangerSigns[index]['description'],
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFFFFF4F4),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.red),
              ),
              padding: const EdgeInsets.all(20),
              margin: const EdgeInsets.symmetric(vertical: 20),
              child: const Text(
                'If any complications occur, seek help immediately to preserve your health and life.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
