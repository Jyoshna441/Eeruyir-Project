import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:photo_view/photo_view.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import 'package:Eeruyir/uril.dart';

class PatientProfile extends StatefulWidget {
  final String patientId;

  PatientProfile({required this.patientId});

  @override
  _PatientProfileState createState() => _PatientProfileState();
}

class _PatientProfileState extends State<PatientProfile> {
  late Map<String, dynamic> patientData;
  late List<dynamic> images;
  bool isImagesVisible = false;
  String? profileImageUrl;

  @override
  void initState() {
    super.initState();
    patientData = {};
    images = [];
    _fetchPatientDetails();
    _fetchProfilePicture(); // Fetch the profile image when the screen loads
  }

  // Fetch patient details from the server
  Future<void> _fetchPatientDetails() async {
    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/profile.php'),
        body: jsonEncode({'patient_id': widget.patientId}),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        if (responseData['success']) {
          setState(() {
            patientData = responseData['patient'] ?? {};
            images = responseData['images'] ?? [];
          });
        } else {
          print('Patient not found');
        }
      } else {
        print('Failed to load patient details');
      }
    } catch (error) {
      print('Error occurred: $error');
    }
  }

  // Fetch profile picture from the server
  Future<void> _fetchProfilePicture() async {
    try {
      final response = await http.get(
        Uri.parse(
            '${Urils.Url}/Eeruyir/profileimage.php?patient_id=${widget.patientId}'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['profile_photo'] != null) {
          setState(() {
            profileImageUrl =
                "${data['profile_photo']}?t=${DateTime.now().millisecondsSinceEpoch}";
          });
        }
      } else {
        print('Failed to fetch profile picture');
      }
    } catch (error) {
      print('Error occurred while fetching profile picture: $error');
    }
  }

  // Toggle visibility of uploaded images
  void _toggleImageVisibility() {
    setState(() {
      isImagesVisible = !isImagesVisible;
    });
  }

  // Upload profile picture
  Future<void> _uploadProfilePicture() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      final file = File(pickedFile.path);
      final request = http.MultipartRequest(
          'POST', Uri.parse('${Urils.Url}/Eeruyir/profileimage.php'));

      // Attach patientId and image file
      request.fields['patient_id'] = widget.patientId;
      request.files
          .add(await http.MultipartFile.fromPath('profileImage', file.path));

      try {
        final response = await request.send();

        if (response.statusCode == 200) {
          final responseData = await response.stream.bytesToString();
          final data = json.decode(responseData);
          if (data['message'] != null) {
            ScaffoldMessenger.of(context)
                .showSnackBar(SnackBar(content: Text(data['message'])));
            // Fetch updated profile picture after upload
            _fetchProfilePicture();
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Failed to upload profile image.')));
        }
      } catch (e) {
        print('Error: $e');
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error occurred during upload.')));
      }
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('No image selected.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Patient Profile',
          style: TextStyle(
              fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: patientData.isEmpty
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: ListView(
                children: [
                  _buildProfileImage(),
                  SizedBox(height: 20),
                  _buildPatientDetails(),
                  SizedBox(height: 20),
                  _buildImagesToggleButton(),
                  SizedBox(height: 10),
                  if (isImagesVisible) _buildImagesSection(),
                  SizedBox(height: 20),
                  // ElevatedButton(
                  //   onPressed: _uploadProfilePicture,
                  //   style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF007DFE)),
                  //   child: Text('Upload Profile Picture', style: TextStyle(fontSize: 16)),
                  // ),
                ],
              ),
            ),
    );
  }

  // Widget _buildProfileImage() {
  //   return Center(
  //     child: Stack(
  //       alignment: Alignment.bottomRight,
  //       children: [
  //         // Display the profile image
  //         profileImageUrl != null
  //             ? ClipRRect(
  //                 borderRadius: BorderRadius.circular(15.0),
  //                 child: Image.network(
  //                   profileImageUrl!,
  //                   height: 150,
  //                   width: 150,
  //                   fit: BoxFit.cover,
  //                 ),
  //               )
  //             : ClipRRect(
  //                 borderRadius: BorderRadius.circular(15.0),
  //                 child: Container(
  //                   color: Colors.grey[200],
  //                   height: 150,
  //                   width: 150,
  //                   child: Icon(
  //                     Icons.account_circle,
  //                     size: 80,
  //                     color: Colors.grey[600],
  //                   ),
  //                 ),
  //               ),
  //         // "+" button for uploading image
  //         Positioned(
  //           right: 0,
  //           bottom: 0,
  //           child: IconButton(
  //             icon: Icon(
  //               Icons.add_circle,
  //               color: const Color.fromARGB(255, 230, 231, 232),
  //               size: 40,
  //             ),
  //             onPressed: _uploadProfilePicture,
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }

  Widget _buildProfileImage() {
    return Center(
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(15.0),
            child: profileImageUrl != null
                ? Image.network(
                    profileImageUrl!,
                    height: 150,
                    width: 150,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      color: Colors.grey[200],
                      height: 150,
                      width: 150,
                      child: Icon(Icons.account_circle,
                          size: 80, color: Colors.grey[600]),
                    ),
                  )
                : Container(
                    color: Colors.grey[200],
                    height: 150,
                    width: 150,
                    child: Icon(Icons.account_circle,
                        size: 80, color: Colors.grey[600]),
                  ),
          ),
          Positioned(
            right: 0,
            bottom: 0,
            child: IconButton(
              icon: Icon(Icons.add_circle, color: Colors.blue, size: 40),
              onPressed: _uploadProfilePicture,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPatientDetails() {
    return Card(
      elevation: 8.0,
      shadowColor: Colors.grey.withOpacity(0.3),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      child: Padding(
        padding: const EdgeInsets.all(17.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTextField('Patient ID', widget.patientId),
            _buildTextField('First Name', patientData['firstName']),
            _buildTextField('Last Name', patientData['lastName']),
            _buildTextField('Age', patientData['age']),
            _buildTextField('Education', patientData['education']),
            _buildTextField('Occupation', patientData['occupation']),
            _buildTextField('Phone Number', patientData['phoneNumber']),
            _buildTextField('Blood Group', patientData['bloodGroup']),
            _buildTextField('LMP Date', patientData['lmpDate']),
            _buildTextField('Due Date', patientData['dueDate']),
            _buildTextField('Abortion History', patientData['abortionHistory']),
            _buildTextField(
                'Relative to Husband', patientData['relativeToHusband']),
            _buildTextField('Confirmation of Pregnancy',
                patientData['confirmationOfPregnancy']),
            _buildTextField('Weight', patientData['weight']),
            _buildTextField('Obstetric Score', patientData['obstetricScore']),
            _buildTextField('Marital Status', patientData['maritalStatus']),
            _buildTextField('Height', patientData['Height']),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
              child: Text(label,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black))),
          SizedBox(width: 10),
          Expanded(
            child: TextFormField(
              initialValue: (value ?? 'N/A').toString(),
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                filled: true,
                fillColor: const Color(0xFFEAF2FF),
                enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: Color(0xFF007DFE), width: 1.5)),
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF007DFE), width: 2)),
              ),
              style: TextStyle(fontSize: 16, color: const Color(0xFF334257)),
              readOnly: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImagesToggleButton() {
    return ElevatedButton(
      onPressed: _toggleImageVisibility,
      style: ElevatedButton.styleFrom(
        backgroundColor: Color(0xFF007DFE),
        padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 30.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
      child: Text(
        isImagesVisible ? 'Hide Uploaded Images' : 'Show Uploaded Images',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: Colors.white, // Explicitly set text color to white
        ),
      ),
    );
  }

  Widget _buildImagesSection() {
    return images.isEmpty
        ? Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Text(
              'No uploaded scans available.',
              style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
            ),
          )
        : GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10.0,
              mainAxisSpacing: 10.0,
            ),
            itemCount: images.length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              String imageUrl =
                  '${Urils.Url}/Eeruyir/${images[index]['file_path']}';
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ImageViewer(imageUrl: imageUrl),
                    ),
                  );
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                  ),
                ),
              );
            },
          );
  }
}

class ImageViewer extends StatelessWidget {
  final String imageUrl;

  const ImageViewer({Key? key, required this.imageUrl}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image Viewer'),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: PhotoView(
          imageProvider: NetworkImage(imageUrl),
          minScale: PhotoViewComputedScale.contained,
          maxScale: PhotoViewComputedScale.covered,
        ),
      ),
    );
  }
}
