import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:Eeruyir/patientdashboard.dart';
import 'package:Eeruyir/uril.dart';

class MonthQuestion extends StatefulWidget {
  final String patientId;

  const MonthQuestion({super.key, required this.patientId});

  @override
  _MonthQuestionState createState() => _MonthQuestionState();
}

class _MonthQuestionState extends State<MonthQuestion> {
  List<dynamic> questions = [];
  bool loading = true;
  String? error;
  Map<int, String> answers = {}; // Store Yes/No answers
  bool hasAnsweredToday = false;

  @override
  void initState() {
    super.initState();
    fetchQuestions();
    checkIfAnsweredToday();
    checkDefaulters();
  }

  Future<void> fetchQuestions() async {
    try {
      final response = await http.get(Uri.parse(
          '${Urils.Url}/Eeruyir/filerecur.php?patient_id=${widget.patientId}'));
      if (response.statusCode == 200) {
        setState(() {
          questions = json.decode(response.body);
        });
      } else {
        setState(() {
          error = 'Failed to fetch questions.';
        });
      }
    } catch (e) {
      setState(() {
        error = 'An error occurred while fetching data.';
      });
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> checkIfAnsweredToday() async {
    String todayFormatted = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final response = await http.get(Uri.parse(
        '${Urils.Url}/Eeruyir/check_answers.php?patient_id=${widget.patientId}&date=$todayFormatted'));
    final data = json.decode(response.body);
    if (data['hasAnswered']) {
      setState(() {
        hasAnsweredToday = true;
      });
    }
  }

  Future<void> checkDefaulters() async {
    try {
      final response = await http.get(Uri.parse(
          '${Urils.Url}/Eeruyir/check_defaulters.php?patient_id=${widget.patientId}'));
      final data = json.decode(response.body);
      // Handle the response if needed
    } catch (e) {
      print('Error checking defaulters: $e');
    }
  }

  void handleAnswerChange(int questionId, String answer) {
    setState(() {
      answers[questionId] = answer;
    });
  }

  Future<void> submitAnswers() async {
    bool highRisk = answers.values.contains('yes');

    if (highRisk) {
      showDialog(
          context: context,
          builder: (context) => AlertDialog(
                title: const Text('High Risk'),
                content: const Text(
                    'You are under high risk. Please consult the doctor.'),
                actions: [
                  TextButton(
                    child: const Text('OK'),
                    onPressed: () async {
                      Navigator.pop(context);
                      try {
                        final response = await http.post(
                            Uri.parse(
                                '${Urils.Url}/Eeruyir/block_patient.php?patient_id=${widget.patientId}'),
                            headers: {'Content-Type': 'application/json'},
                            body: json.encode({}));

                        final data = json.decode(response.body);
                        if (data['success'] == 'true') {
                          // Compare with 'true' string
                          showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                    title: const Text('Success'),
                                    content: const Text(
                                        'Your account has been blocked.'),
                                    actions: [
                                      TextButton(
                                          child: const Text('OK'),
                                          onPressed: () {
                                            Navigator.popUntil(context,
                                                (route) => route.isFirst);
                                          })
                                    ],
                                  ));
                        } else {
                          showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                    title: const Text('Error'),
                                    content: Text(data['error'] ??
                                        'Failed to block the account.'),
                                    actions: [
                                      TextButton(
                                          child: const Text('OK'),
                                          onPressed: () {
                                            Navigator.pop(context);
                                          })
                                    ],
                                  ));
                        }
                      } catch (e) {
                        showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                                  title: const Text('Error'),
                                  content: const Text(
                                      'An error occurred while blocking the account.'),
                                  actions: [
                                    TextButton(
                                        child: const Text('OK'),
                                        onPressed: () {
                                          Navigator.pop(context);
                                        })
                                  ],
                                ));
                      }
                    },
                  ),
                ],
              ));
      return;
    }

    try {
      final response =
          await http.post(Uri.parse('${Urils.Url}/Eeruyir/submit_answers.php'),
              headers: {'Content-Type': 'application/json'},
              body: json.encode({
                'patient_id': widget.patientId,
                'answers': answers.entries.map((entry) {
                  return {
                    'question_id': entry.key,
                    'answer': entry.value,
                  };
                }).toList(),
              }));

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}'); // Log the response

      final data = json.decode(response.body);
      if (data['success'] == 'Answers saved successfully') {
        // Check for the success string
        showDialog(
            context: context,
            builder: (context) => AlertDialog(
                  title: const Text('Success'),
                  content: const Text('Answers saved successfully!'),
                  actions: [
                    TextButton(
                        child: const Text('OK'),
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => PatientDashboard(
                                patientId: widget.patientId,
                              ),
                            ),
                          );
                        })
                  ],
                ));
      } else {
        showDialog(
            context: context,
            builder: (context) => AlertDialog(
                  title: const Text('Error'),
                  content: Text(data['error'] ?? 'Failed to save answers.'),
                  actions: [
                    TextButton(
                        child: const Text('OK'),
                        onPressed: () {
                          Navigator.pop(context);
                        })
                  ],
                ));
      }
    } catch (e) {
      print('Error submitting answers: $e');
      showDialog(
          context: context,
          builder: (context) => AlertDialog(
                title: const Text('Error'),
                content: const Text('An error occurred while saving answers.'),
                actions: [
                  TextButton(
                      child: const Text('OK'),
                      onPressed: () {
                        // Navigate to the PatientDashboard with patient_id
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => PatientDashboard(
                              patientId: widget.patientId,
                            ),
                          ),
                        );
                      })
                ],
              ));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator(color: Colors.blue));
    }

    if (error != null) {
      return Center(
        child: Text(
          error!,
          style: const TextStyle(color: Colors.red, fontSize: 16),
        ),
      );
    }

    if (hasAnsweredToday || questions.contains(1) || questions.isEmpty) {
      return Scaffold(
        backgroundColor: Colors.white, // Set the background color to white
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              Navigator.pop(
                  context); // Navigate back when the back button is pressed
            },
          ),
          title: Text('Monthly Questions',
              style: TextStyle(color: Colors.white)), // Title
          backgroundColor:
              const Color(0xFF007DFE), // AppBar background color to white
          elevation: 0, // Optional: removes shadow under the AppBar
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.check_circle,
                  size: 80, color: const Color.fromRGBO(33, 150, 243, 1)),
              SizedBox(height: 10),
              Text(
                'No more questions for today',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Questions',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: questions.length,
                itemBuilder: (context, index) {
                  final question = questions[index];
                  return Card(
                    elevation: 5,
                    margin: const EdgeInsets.only(bottom: 10),
                    child: Padding(
                      padding: const EdgeInsets.all(15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(question['question'],
                              style: const TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold)),
                          if (question['sub_question'] != null)
                            Text(question['sub_question'],
                                style: const TextStyle(fontSize: 16)),
                          const SizedBox(height: 10),
                          Text('Date: ${question['exact_date']}',
                              style: const TextStyle(color: Colors.grey)),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      answers[question['id']] == 'yes'
                                          ? Colors.blue
                                          : Colors.grey,
                                ),
                                onPressed: () =>
                                    handleAnswerChange(question['id'], 'yes'),
                                child: const Text('Yes'),
                              ),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      answers[question['id']] == 'no'
                                          ? Colors.blue
                                          : Colors.grey,
                                ),
                                onPressed: () =>
                                    handleAnswerChange(question['id'], 'no'),
                                child: const Text('No'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: submitAnswers,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
              ),
              child: const Text('Submit Answers'),
            ),
          ],
        ),
      ),
    );
  }
}
