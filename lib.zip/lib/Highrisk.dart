import 'package:flutter/material.dart';
import 'dart:convert'; // For JSON decoding
import 'package:http/http.dart' as http;
import 'package:Eeruyir/uril.dart';

class Highrisk extends StatefulWidget {
  const Highrisk({super.key});

  @override
  _HighriskState createState() => _HighriskState();
}

class _HighriskState extends State<Highrisk> {
  List patients = [];
  bool loading = true;
  Map<String, dynamic>? selectedPatient;
  String questions = '';

  // Fetch high-risk patients
  Future<void> fetchPatients() async {
    try {
      final response =
          await http.get(Uri.parse('${Urils.Url}/Eeruyir/Highrisk.php'));
      final data = json.decode(response.body);

      if (data['success']) {
        setState(() {
          patients = data['data'];
        });
      } else {
        _showAlert('No high-risk patients found.');
      }
    } catch (error) {
      print('Error fetching patients: $error');
      _showAlert('Error fetching patients.');
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  // Handle patient selection
  void handlePatientSelect(Map<String, dynamic> patient) {
    setState(() {
      selectedPatient = patient;
      questions = patient['high_risk_questions'] ?? '';
    });
  }

  // Alert dialog
  void _showAlert(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Alert'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: const Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    fetchPatients();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'High Risk Patients',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF0072FF),
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: patients.length,
                    itemBuilder: (context, index) {
                      final patient = patients[index];
                      return GestureDetector(
                        onTap: () => handlePatientSelect(patient),
                        child: Container(
                          padding: const EdgeInsets.all(15),
                          margin: const EdgeInsets.symmetric(
                              vertical: 5, horizontal: 20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(color: const Color(0xFF0072FF)),
                          ),
                          child: Text(
                            'Patient ID: ${patient['patient_id']}',
                            style: const TextStyle(
                                fontSize: 16, color: Colors.black),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                if (selectedPatient != null)
                  Container(
                    margin: const EdgeInsets.all(20),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE6F7FF),
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: const Color(0xFF0072FF)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Questions answered by Patient ID: ${selectedPatient!['patient_id']}',
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 10),
                        questions.isNotEmpty
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: questions.split('; ').map((question) {
                                  return Text(question);
                                }).toList(),
                              )
                            : const Text('No questions answered with "yes".'),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }
}
