import 'package:flutter/material.dart';

class Analytics extends StatelessWidget {
  final Map<String, String> patient = {
    'name': 'John Doe',
    'id': 'ID123456',
    'age': '30',
    'education': 'Bachelor\'s Degree',
    'occupation': 'Software Engineer',
    'phoneno': '1234567890',
    'bloodgroup': 'O+',
    'height': '5.8',
    'weight': '70kg',
    'obstetricsscore': 'G2P1',
    'maritalstatus': 'Married',
  };

  Analytics({super.key});

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Container(
              color: const Color(0xFF007DFE),
            ),
            Positioned(
              top: size.height * 0.03,
              left: size.width * 0.03,
              child: IconButton(
                icon: const Icon(Icons.arrow_back, size: 35, color: Colors.white),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
            Align(
              alignment: const Alignment(0.0, -0.5),
              child: Container(
                width: size.width,
                height: size.height * 0.2,
                margin: EdgeInsets.only(top: size.height * 0.23),
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: size.width * 0.2,
                      backgroundImage: const AssetImage('assets/bg.png'),
                    ),
                    SizedBox(height: size.width * 0.05),
                    Text(
                      patient['name']!,
                      style: TextStyle(
                        fontSize: size.width * 0.06,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      patient['id']!,
                      style: TextStyle(
                        fontSize: size.width * 0.04,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              child: Container(
                width: size.width,
                height: size.height * 0.6,
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
                padding: EdgeInsets.symmetric(horizontal: size.width * 0.05),
                child: Column(
                  children: [
                    buildProfileSection(
                        'Blood group', patient['bloodgroup']!, size),
                    buildProfileSection('Phone no', patient['phoneno']!, size),
                    buildProfileSection(
                        'Marital status', patient['maritalstatus']!, size),
                    buildProfileSection('Weight', patient['weight']!, size),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildProfileSection(String label, String value, Size size) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: size.height * 0.02),
      child: Row(
        children: [
          Text(
            '$label :',
            style: TextStyle(
              fontSize: size.width * 0.04,
            ),
          ),
          SizedBox(width: size.width * 0.02),
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.02),
              height: size.width * 0.1,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(5),
              ),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  value,
                  style: TextStyle(
                      fontSize: size.width * 0.04, color: Colors.black),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
