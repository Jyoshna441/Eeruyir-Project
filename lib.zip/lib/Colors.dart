import 'package:flutter/material.dart';

final Map<String, Color> appColors = {
  'primary': const Color(0xFF0C7DE4),
  'white': const Color(0xFFFFFFFF),
  'gray': const Color(0xFF979191),
  'bgColor': const Color(0xFFF6F8FC),
  'black': const Color(0xFF000000),
  'green': const Color(0xFF0CD650),
};
