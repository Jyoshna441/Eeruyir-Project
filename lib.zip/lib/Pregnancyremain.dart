import 'package:flutter/material.dart';

class PregnancyRemain extends StatefulWidget {
  final DateTime lastPeriodDate;
  final Function(int) onPendingRemindersChange;

  const PregnancyRemain({super.key, 
    required this.lastPeriodDate,
    required this.onPendingRemindersChange,
  });

  @override
  _PregnancyRemainState createState() => _PregnancyRemainState();
}

class _PregnancyRemainState extends State<PregnancyRemain> {
  int currentMonth = 1;
  Map<String, dynamic> testResults = {};
  bool alertShown = false;
  bool dailyAlertDismissed = false;
  int pendingReminders = 0;

  @override
  void initState() {
    super.initState();
    calculatePregnancyMonth();
  }

  void calculatePregnancyMonth() {
    final currentDate = DateTime.now();
    int monthsDiff = currentDate.month - widget.lastPeriodDate.month +
        (12 * (currentDate.year - widget.lastPeriodDate.year));
    setState(() {
      currentMonth = monthsDiff + 1;
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!dailyAlertDismissed && !alertShown) {
      setState(() {
        pendingReminders++;
      });
    }
    widget.onPendingRemindersChange(pendingReminders);
  }

  void handleYesResponse(int month) {
    setState(() {
      testResults[month.toString()] = true;
      alertShown = true;
      pendingReminders--;
    });
  }

  void handleNoResponse() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Reminder"),
        content: const Text("Please do the testing and consult the doctor as soon as possible."),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("OK"),
          ),
        ],
      ),
    );
    setState(() {
      dailyAlertDismissed = true;
    });
  }

  Widget renderAlertMessage() {
    if (dailyAlertDismissed || alertShown) return Container();

    String alertMessage = '';
    String testsRequired = '';

    switch (currentMonth) {
      case 1:
      case 2:
      case 3:
        alertMessage = 'Please do blood tests (HB, HIV, HbSAg, VDRL, Thyroid) and NT scan.';
        testsRequired = 'HB, HIV, HbSAg, VDRL, NT Scan';
        break;
      case 4:
        alertMessage = 'Please do blood tests (HB, GCT).';
        testsRequired = 'HB, GCT';
        break;
      case 5:
        alertMessage = 'Please do blood tests (HB) and an Anomaly Scan.';
        testsRequired = 'HB, Anomaly Scan';
        break;
      case 6:
        alertMessage = 'Please do blood tests (HB, GCT).';
        testsRequired = 'HB, GCT';
        break;
      case 7:
        alertMessage = 'Please do blood tests (HB) and a Growth Scan.';
        testsRequired = 'HB, Growth Scan';
        break;
      case 8:
        alertMessage = 'Please do blood tests (HB, GCT).';
        testsRequired = 'HB, GCT';
        break;
      case 9:
        alertMessage = 'Please do blood tests (HB) and a Growth Scan.';
        testsRequired = 'HB, Growth Scan';
        break;
      default:
        return Container();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(alertMessage),
        Text('Have you done the tests ($testsRequired)?'),
        Row(
          children: [
            TextButton(
              onPressed: () => handleYesResponse(currentMonth),
              child: const Text('Yes'),
            ),
            TextButton(
              onPressed: handleNoResponse,
              child: const Text('No'),
            ),
          ],
        ),
        TextField(
          decoration: const InputDecoration(
            hintText: 'Enter HB level',
          ),
          onChanged: (text) {
            setState(() {
              testResults['HB'] = text;
            });
          },
        ),
        TextField(
          decoration: const InputDecoration(
            hintText: 'Enter HIV status (Negative/Positive)',
          ),
          onChanged: (text) {
            setState(() {
              testResults['HIV'] = text;
            });
          },
        ),
        ElevatedButton(
          onPressed: () {
            // Upload functionality
          },
          child: const Text('Upload Scan Picture'),
        ),
        const Text('Have you consulted the doctor with reports?'),
        Row(
          children: [
            TextButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text("Data Saved"),
                    content: const Text("Your data has been saved."),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text("OK"),
                      ),
                    ],
                  ),
                );
              },
              child: const Text('Yes'),
            ),
            TextButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text("Reminder"),
                    content: const Text("Please consult the doctor with reports."),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text("OK"),
                      ),
                    ],
                  ),
                );
              },
              child: const Text('No'),
            ),
          ],
        ),
        const Text('(Disclaimer: Entry for record purposes only, not for consultation. Please consult the doctor.)'),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      child: renderAlertMessage(),
    );
  }
}
