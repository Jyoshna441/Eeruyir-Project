import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:Eeruyir/uril.dart';

class TestResultsScreen extends StatefulWidget {
  final String patientId;

  const TestResultsScreen({super.key, required this.patientId});

  @override
  _TestResultsScreenState createState() => _TestResultsScreenState();
}

class _TestResultsScreenState extends State<TestResultsScreen> {
  final TextEditingController _testTypeController = TextEditingController();
  final TextEditingController _resultController = TextEditingController();
  final TextEditingController _scanImageController = TextEditingController();

  Future<void> submitResults() async {
    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/store_test_results.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: jsonEncode({
          'patient_id': widget.patientId,
          'testType': _testTypeController.text,
          'result': _resultController.text,
          'scanImage': _scanImageController.text,
        }),
      );

      final data = jsonDecode(response.body);
      if (data['message'] != null) {
        // Show success or error message
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            content: Text(data['message']),
            actions: [
              TextButton(
                child: const Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop(); // Close dialog
                },
              ),
            ],
          ),
        );
      } else {
        // Handle case when message is not present
        print('Error storing test results');
      }
    } catch (error) {
      print('Error submitting test results: $error');
      // Optionally show an alert for error
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          content: Text('Error submitting test results: $error'),
          actions: [
            TextButton(
              child: const Text('OK'),
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
              },
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Test Results'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: TextEditingController(text: widget.patientId),
              readOnly: true, // Patient ID is not editable
              decoration: const InputDecoration(
                labelText: 'Patient ID',
              ),
            ),
            TextField(
              controller: _testTypeController,
              decoration: const InputDecoration(
                labelText: 'Test Type',
              ),
            ),
            TextField(
              controller: _resultController,
              decoration: const InputDecoration(
                labelText: 'Result',
              ),
            ),
            TextField(
              controller: _scanImageController,
              decoration: const InputDecoration(
                labelText: 'Scan Image (Base64)',
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: submitResults,
              child: const Text('Submit Results'),
            ),
          ],
        ),
      ),
    );
  }
}
