import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/patientdashboard.dart';
import 'package:Eeruyir/uril.dart';

class OutcomeOfDeliveryScreen extends StatelessWidget {
  final String patientId;

  const OutcomeOfDeliveryScreen({super.key, required this.patientId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Outcome of Delivery',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Outcome of Delivery',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF007BFF)),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _handleAlert(context),
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFF007BFF), // Button background color
                foregroundColor: Colors.white, // Text color
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text('Click to enter delivery outcome'),
            ),
          ],
        ),
      ),
    );
  }

  void _handleAlert(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Important'),
          content: const Text('To be filled only after delivery'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the alert dialog
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        ModeOfDeliveryScreen(patientId: patientId),
                  ),
                );
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
}

class ModeOfDeliveryScreen extends StatefulWidget {
  final String patientId;

  const ModeOfDeliveryScreen({super.key, required this.patientId});

  @override
  _ModeOfDeliveryScreenState createState() => _ModeOfDeliveryScreenState();
}

class _ModeOfDeliveryScreenState extends State<ModeOfDeliveryScreen> {
  String deliveryMethod = '';
  String? difficulty;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Outcome of Delivery',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Which method did you deliver the baby?',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            _buildDeliveryOption('Normal Vaginal Delivery'),
            if (deliveryMethod == 'Normal') _buildDifficultyOption(),
            _buildDeliveryOption('C-Section'),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _handleSave,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 172, 201, 233),
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeliveryOption(String method) {
    return Column(
      children: [
        Text(
          method,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        ElevatedButton(
          onPressed: () {
            setState(() {
              deliveryMethod =
                  method == 'Normal Vaginal Delivery' ? 'Normal' : 'C-Section';
              difficulty =
                  null; // Reset difficulty when changing delivery method
            });
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: deliveryMethod == 'Normal' &&
                        method == 'Normal Vaginal Delivery' ||
                    deliveryMethod == 'C-Section' && method == 'C-Section'
                ? const Color.fromARGB(255, 214, 196, 214)
                : const Color.fromARGB(255, 186, 193, 200),
            padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 30),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
          child: const Text('Select'),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildDifficultyOption() {
    return Column(
      children: [
        const Text(
          'Was there any difficulty in delivery (e.g., forceps, vacuum delivery)?',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ElevatedButton(
              onPressed: () {
                setState(() {
                  difficulty = 'Yes';
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: difficulty == 'Yes'
                    ? const Color.fromARGB(255, 214, 196, 214)
                    : const Color.fromARGB(255, 186, 193, 200),
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              ),
              child: const Text('Yes'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  difficulty = 'No';
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: difficulty == 'No'
                    ? const Color.fromARGB(255, 214, 196, 214)
                    : const Color.fromARGB(255, 186, 193, 200),
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              ),
              child: const Text('No'),
            ),
          ],
        ),
      ],
    );
  }

  void _handleSave() async {
    if (deliveryMethod.isEmpty) {
      _showAlert('Error', 'Please select a delivery method.');
      return;
    }

    final data = {
      'patient_id': widget.patientId,
      'delivery_method': deliveryMethod,
      'difficulty': difficulty ?? '', // Handle nullable value
    };

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/deliveryoutcome.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: data,
      );

      final result = json.decode(response.body);

      if (result['status'] == 'success') {
        // Display success dialog and navigate to Patient Dashboard
        _showAlert('Success', 'Outcome Stored', onDismiss: () {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  PatientDashboard(patientId: widget.patientId),
            ),
            (route) => false, // Clear the navigation stack
          );
        });
      } else {
        _showAlert('Error', result['message']);
      }
    } catch (error) {
      _showAlert('Error', 'Failed to save delivery data.');
      print('Error: $error');
    }
  }

  void _showAlert(String title, String message, {VoidCallback? onDismiss}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog
                if (onDismiss != null) {
                  onDismiss(); // Execute the onDismiss callback if provided
                }
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
