import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:Eeruyir/Doctorlogin.dart';
import 'package:Eeruyir/uril.dart';

class DocSignScreen extends StatefulWidget {
  const DocSignScreen({super.key});

  @override
  _DocSignScreenState createState() => _DocSignScreenState();
}

class _DocSignScreenState extends State<DocSignScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController reEnterPasswordController =
      TextEditingController();
  final TextEditingController specializationController =
      TextEditingController();
  final TextEditingController experienceController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  void handleSignup() async {
    // Validate phone number
    String phoneNumber = phoneNumberController.text;
    if (phoneNumber.isEmpty || !RegExp(r'^[0-9]+$').hasMatch(phoneNumber)) {
      _showErrorDialog('Please provide a valid phone number.');
      return;
    }

    // Validate username, password, and re-entered password
    String username = usernameController.text;
    if (username.isEmpty) {
      _showErrorDialog('Please provide a valid username');
      return;
    }

    String password = passwordController.text;
    String reEnterPassword = reEnterPasswordController.text;

    if (password.isEmpty || reEnterPassword.isEmpty) {
      _showErrorDialog('Please provide all the information.');
      return;
    }

    if (password != reEnterPassword) {
      _showErrorDialog('Passwords do not match.');
      return;
    }

    // Prepare data for the POST request
    Map<String, dynamic> formData = {
      'username': username,
      'phonenumber': phoneNumber,
      'password': password,
      're_enter_password': reEnterPassword,
      'specialization': specializationController.text,
      'experience': experienceController.text,
      'name': nameController.text,
      'email': emailController.text,
    };

    // Make the POST request
    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/doctorprofile.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(formData),
      );

      final data = jsonDecode(response.body);
      if (data['success'] == false) {
        _showErrorDialog(data['message']);
      } else {
        _showSuccessDialog('Registration successful');
        // Navigate to the login screen
        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => const DoctorLogin()),
        );
      }
    } catch (e) {
      print('Error: $e');
      _showErrorDialog('Network error. Please try again.');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            child: const Text('Okay'),
            onPressed: () {
              Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  void _showSuccessDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Success'),
        content: Text(message),
        actions: [
          TextButton(
            child: const Text('Okay'),
            onPressed: () {
              Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Sign Up',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // const Text(
              //   'SIGN UP',
              //   style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              // ),
              const SizedBox(height: 40),
              _buildTextField(usernameController, 'Username', false),
              _buildTextField(phoneNumberController, 'Phone Number', false),
              _buildTextField(passwordController, 'Password', true),
              _buildTextField(
                  reEnterPasswordController, 'Re-enter Password', true),
              _buildTextField(
                  specializationController, 'Specialization', false),
              _buildTextField(experienceController, 'Experience', false,
                  isNumeric: true),
              _buildTextField(nameController, 'Name', false),
              _buildTextField(emailController, 'Email', false, isEmail: true),
              ElevatedButton(
                onPressed: handleSignup,
                style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                  backgroundColor: const Color(0xFF007DFE),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
                child: const Text('Signup'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String hintText, bool isObscure,
      {bool isNumeric = false, bool isEmail = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: TextFormField(
        controller: controller,
        obscureText: isObscure,
        keyboardType: isNumeric
            ? TextInputType.number
            : (isEmail ? TextInputType.emailAddress : TextInputType.text),
        decoration: InputDecoration(
          border: const OutlineInputBorder(),
          hintText: hintText,
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your $hintText';
          }
          return null;
        },
      ),
    );
  }
}
