import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/PatientProfile.dart';
import 'package:Eeruyir/uril.dart'; // Import your PatientProfile screen

class BlockScreen extends StatefulWidget {
  @override
  _BlockScreenState createState() => _BlockScreenState();
}

class _BlockScreenState extends State<BlockScreen> {
  List<dynamic> blockedPatients = [];
  bool loading = true;
  String? error;
  String? message; // To hold custom message like "No blocked patients found."

  @override
  void initState() {
    super.initState();
    fetchBlockedPatients();
  }

  Future<void> fetchBlockedPatients() async {
    try {
      final response =
          await http.get(Uri.parse('${Urils.Url}/Eeruyir/blocklist.php'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data is List) {
          setState(() {
            blockedPatients = data;
            loading = false;
          });
        } else if (data['message'] == 'No blocked patients found.') {
          setState(() {
            message = 'No Patients Found'; // Handle the specific response
            loading = false;
          });
        } else {
          setState(() {
            error = data['message'];
            loading = false;
          });
        }
      } else {
        throw Exception('Network response was not ok');
      }
    } catch (err) {
      setState(() {
        error = err.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (error != null) {
      return Center(
        child: Text(
          'Error: $error',
          style: const TextStyle(color: Colors.red, fontSize: 18),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Blocked Patients',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: message != null
          ? Center(
              child: Text(
                message!,
                style: const TextStyle(fontSize: 18, color: Colors.black),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: blockedPatients.length,
              itemBuilder: (context, index) {
                final patient = blockedPatients[index];
                return Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  margin: const EdgeInsets.only(bottom: 16),
                  child: InkWell(
                    onTap: () {
                      // Navigate to the PatientProfile screen when tapped
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              PatientProfile(patientId: patient['patient_id']),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Patient ID: ${patient['patient_id']}',
                            style: const TextStyle(
                              fontSize: 16,
                              color: Color(0xFF616161),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
