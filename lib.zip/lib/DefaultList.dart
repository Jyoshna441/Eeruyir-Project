import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:Eeruyir/uril.dart';

class DefaultList extends StatefulWidget {
  const DefaultList({super.key});

  @override
  _DefaultListState createState() => _DefaultListState();
}

class _DefaultListState extends State<DefaultList> {
  List defaulters = [];
  List filteredDefaulters = [];
  bool isLoading = true;
  String? selectedPatientId;
  String alertMessage = '';
  TextEditingController searchController = TextEditingController();

  // Function to fetch defaulters from the backend
  // Future<void> fetchDefaulters() async {
  //   try {
  //     final response =
  //         await http.get(Uri.parse('${Urils.Url}/Eeruyir/notblocked.php'));
  //     if (response.statusCode == 200) {
  //       setState(() {
  //         defaulters = json.decode(response.body);
  //         filteredDefaulters = defaulters;
  //         isLoading = false;
  //       });
  //     } else {
  //       throw Exception('Failed to load defaulters');
  //     }
  //   } catch (error) {
  //     print('Error fetching defaulters: $error');
  //     setState(() {
  //       isLoading = false;
  //     });
  //   }
  // }

  Future<void> fetchDefaulters() async {
    try {
      final response =
          await http.get(Uri.parse('${Urils.Url}/Eeruyir/notblocked.php'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // Check if the response contains a specific message
        if (data is Map<String, dynamic> &&
            data['message'] == "No blocked patients found.") {
          showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('No Patients Found'),
              content: const Text('There are no patients to display.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Step 1: Go back once
                    Navigator.of(context).pop(); // Step 2: Go back again
                  },
                  child: const Text('OK'),
                ),
              ],
            ),
          );
          setState(() {
            defaulters = [];
            filteredDefaulters = [];
            isLoading = false;
          });
        } else if (data is List) {
          // If the response contains a list of patients, update the state
          setState(() {
            defaulters = data;
            filteredDefaulters = defaulters;
            isLoading = false;
          });
        } else {
          throw Exception('Unexpected response format');
        }
      } else {
        throw Exception('Failed to load defaulters');
      }
    } catch (error) {
      print('Error fetching defaulters: $error');
      setState(() {
        isLoading = false;
      });
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Error'),
          content:
              const Text('Failed to load patients. Please try again later.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  // Function to handle search input
  void filterDefaulters(String query) {
    List filtered = defaulters
        .where((defaulter) => defaulter['patient_id']
            .toString()
            .toLowerCase()
            .contains(query.toLowerCase()))
        .toList();
    setState(() {
      filteredDefaulters = filtered;
    });
  }

  // Function to send alert
  Future<void> sendAlert() async {
    if (selectedPatientId == null || alertMessage.isEmpty) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Error'),
          content:
              const Text('Please select a patient and enter an alert message.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/send_alert.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'patient_id': selectedPatientId,
          'message': alertMessage,
        }),
      );

      final result = json.decode(response.body);
      if (result['success']) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Success'),
            content: Text('Alert sent to patient ID: $selectedPatientId'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          ),
        );
        setState(() {
          alertMessage = '';
        });
      } else {
        throw Exception('Failed to send alert');
      }
    } catch (error) {
      print('Error sending alert: $error');
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Error'),
          content: const Text('An error occurred while sending the alert.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    fetchDefaulters();
    searchController.addListener(() {
      filterDefaulters(searchController.text);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Alert Patients',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 20),
                  Text('Loading defaulters...'),
                ],
              ),
            )
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    controller: searchController,
                    decoration: const InputDecoration(
                      labelText: 'Search by Patient ID',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                ),
                Expanded(
                  child: filteredDefaulters.isEmpty
                      ? const Center(child: Text('No Patients found.'))
                      : ListView.builder(
                          itemCount: filteredDefaulters.length,
                          itemBuilder: (context, index) {
                            final defaulter = filteredDefaulters[index];
                            return ListTile(
                              title: Text(
                                  'Patient ID: ${defaulter['patient_id']}'),
                              onTap: () {
                                setState(() {
                                  selectedPatientId = defaulter['patient_id'];
                                });
                              },
                              selected:
                                  selectedPatientId == defaulter['patient_id'],
                              selectedTileColor: Colors.blue[100],
                            );
                          },
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      TextField(
                        decoration: const InputDecoration(
                          labelText: 'Enter alert message',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) {
                          setState(() {
                            alertMessage = value;
                          });
                        },
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: sendAlert,
                        child: const Text('Send Alert'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
