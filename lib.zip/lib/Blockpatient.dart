import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/uril.dart';
import 'package:Eeruyir/PatientProfile.dart';

class BlockPatientScreen extends StatefulWidget {
  final Function(String) navigateToProfile;

  const BlockPatientScreen({super.key, required this.navigateToProfile});

  @override
  _BlockPatientScreenState createState() => _BlockPatientScreenState();
}

class _BlockPatientScreenState extends State<BlockPatientScreen> {
  List<dynamic> patients = [];
  List<dynamic> filteredPatients = [];
  bool loading = true;
  String? error;
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    fetchPatients();
  }

  Future<void> fetchPatients() async {
    try {
      final response =
          await http.get(Uri.parse('${Urils.Url}/Eeruyir/notblocked.php'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data is List) {
          // Data is a list of patients
          if (mounted) {
            setState(() {
              patients = data;
              filteredPatients = patients; // Initialize filtered list
              loading = false;
            });
          }
        } else if (data['message'] == "No blocked patients found.") {
          // Handle "No blocked patients found" message
          if (mounted) {
            setState(() {
              patients = [];
              filteredPatients = [];
              loading = false;
            });
          }
        } else {
          throw Exception('Unexpected response format');
        }
      } else {
        throw Exception('Network response was not ok');
      }
    } catch (err) {
      if (mounted) {
        setState(() {
          error = err.toString();
          loading = false;
        });
      }
    }
  }

  Future<void> blockPatient(String patientId) async {
    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/blockuser.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'patient_id': patientId, 'blocked': 1}),
      );

      final result = json.decode(response.body);

      if (result['success'] == true) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Patient ID $patientId is now blocked')),
          );
          fetchPatients(); // Refresh the patient list after blocking
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text(result['error'] ?? 'Failed to block patient')),
          );
        }
      }
    } catch (err) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(err.toString())),
        );
      }
    }
  }

  void updateSearchQuery(String query) {
    setState(() {
      searchQuery = query;
      filteredPatients = patients.where((patient) {
        final fullName =
            '${patient['firstName']} ${patient['lastName']}'.toLowerCase();
        final patientId = patient['patient_id'].toString();
        return fullName.contains(query.toLowerCase()) ||
            patientId.contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (error != null) {
      return Center(
        child: Text(
          'Error: $error',
          style: const TextStyle(color: Colors.red, fontSize: 18),
        ),
      );
    }

    if (filteredPatients.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('No Patients Found'),
              content:
                  const Text('There are no patients available at the moment.'),
              actions: <Widget>[
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                    Navigator.of(context)
                        .pop(); // Go back to the previous screen
                  },
                  child: const Text('OK'),
                ),
              ],
            );
          },
        );
      });

      // Return an empty container or any other fallback widget
      return const Center(child: Text('')); // Empty screen while alert is shown
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Block Patient',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: Container(
        color: const Color(0xFFF2F4F6),
        child: Column(
          children: [
            // Search Bar
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                onChanged: updateSearchQuery,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: 'Search by ID',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: filteredPatients.length,
                itemBuilder: (context, index) {
                  final patient = filteredPatients[index];
                  return Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 8),
                          Text(
                            'Patient ID: ${patient['patient_id']}',
                            style: const TextStyle(
                              fontSize: 16,
                              color: Color(0xFF616161),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      const Color.fromARGB(255, 147, 160, 219),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20, vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                onPressed: () =>
                                    blockPatient(patient['patient_id']),
                                child: const Text(
                                  'Block',
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.white),
                                ),
                              ),
                              TextButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => PatientProfile(
                                          patientId: patient['patient_id']),
                                    ),
                                  );
                                },
                                child: const Text(
                                  'View Profile',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Color(0xFF0072FF),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    // Clean up resources here if needed
    super.dispose();
  }
}
