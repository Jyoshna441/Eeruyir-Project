import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

class BumpGalleryScreen extends StatefulWidget {
  final String patientId;

  const BumpGalleryScreen({super.key, required this.patientId});

  @override
  _BumpGalleryScreenState createState() => _BumpGalleryScreenState();
}

class _BumpGalleryScreenState extends State<BumpGalleryScreen> {
  final List<String> photos = [];
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    loadPhotos();
  }

  Future<void> loadPhotos() async {
    final directory = await getApplicationDocumentsDirectory();
    final dirPath = '${directory.path}/bumpGallery/${widget.patientId}';
    final directoryExists = await Directory(dirPath).exists();

    if (directoryExists) {
      final dir = Directory(dirPath);
      final List<FileSystemEntity> files = dir.listSync();
      setState(() {
        photos.clear();
        photos.addAll(files.map((file) => file.path).toList());
      });
    } else {
      await Directory(dirPath).create(recursive: true);
    }
  }

  Future<void> takePhoto() async {
    final XFile? photo = await _picker.pickImage(source: ImageSource.camera);

    if (photo != null) {
      final fileName = photo.name;
      final directory = await getApplicationDocumentsDirectory();
      final destPath =
          '${directory.path}/bumpGallery/${widget.patientId}/$fileName';

      await File(photo.path).copy(destPath);
      setState(() {
        photos.add(destPath);
      });
    } else {
      _showErrorDialog('Failed to take photo. Please try again.');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK')),
        ],
      ),
    );
  }

  void viewImage(String imagePath) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => ViewImageScreen(imagePath: imagePath),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bump Gallery'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: takePhoto,
              child: const Text('Take Photo'),
            ),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: 1,
                ),
                itemCount: photos.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () => viewImage(photos[index]),
                    child: Container(
                      margin: const EdgeInsets.all(4.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        image: DecorationImage(
                          image: FileImage(File(photos[index])),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ViewImageScreen extends StatelessWidget {
  final String imagePath;

  const ViewImageScreen({super.key, required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Image'),
      ),
      body: Center(
        child: Image.file(File(imagePath)),
      ),
    );
  }
}
