import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/uril.dart';

class MentalHealthTable extends StatefulWidget {
  const MentalHealthTable({super.key});

  @override
  _MentalHealthTableState createState() => _MentalHealthTableState();
}

class _MentalHealthTableState extends State<MentalHealthTable> {
  List<dynamic> data = [];

  @override
  void initState() {
    super.initState();
    fetchMentalHealthData();
  }

  Future<void> fetchMentalHealthData() async {
    try {
      final response = await http.get(Uri.parse(
          '${Urils.Url}/Eeruyir/getPatients.php')); // Replace with your actual API endpoint
      if (response.statusCode == 200) {
        setState(() {
          data = json.decode(response.body);
        });
      } else {
        throw Exception('Failed to load data');
      }
    } catch (error) {
      print('Error fetching mental health data: $error');
      setState(() {
        data = [];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mental Health Data')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(10.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeader(),
              ...data
                  .asMap()
                  .entries
                  .map((entry) => _buildRow(entry.key, entry.value)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildHeaderCell('S NO'),
        _buildHeaderCell('PATIENT ID'),
        _buildHeaderCell('MORE RELAXED'),
        _buildHeaderCell('HAPPY'),
        _buildHeaderCell('LESS ANXIOUS'),
        _buildHeaderCell('NO CHANGE'),
      ],
    );
  }

  Widget _buildHeaderCell(String text) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        color: Colors.grey[300],
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildRow(int index, dynamic item) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildCell((index + 1).toString()),
        _buildCell(item['patientId'].toString()),
        _buildCell('${item['moreRelaxed']} TIMES'),
        _buildCell('${item['happy']} TIMES'),
        _buildCell('${item['lessAnxious']} TIMES'),
        _buildCell(
            '${item['noChange']} TIME${item['noChange'] != 1 ? 'S' : ''}'),
      ],
    );
  }

  Widget _buildCell(String text) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: Colors.grey)),
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
