import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'uril.dart';

class BabyKickCountScreen extends StatefulWidget {
  final String patientId;
  final int weeks;

  const BabyKickCountScreen(
      {super.key, required this.patientId, required this.weeks});

  @override
  _BabyKickCountScreenState createState() => _BabyKickCountScreenState();
}

class _BabyKickCountScreenState extends State<BabyKickCountScreen> {
  int kickCount = 0;
  bool isLoading = false;
  String error = '';

  @override
  void initState() {
    super.initState();
    fetchKickCount();
  }

  // Check if the pregnancy is beyond 20 weeks
  bool isEligibleToCount() {
    return widget.weeks >= 20;
  }

  // Function to fetch the initial kick count
  Future<void> fetchKickCount() async {
    setState(() {
      isLoading = true;
    });

    try {
      final response = await http.get(Uri.parse(
          '${Urils.Url}/Eeruyir/kickcount.php?patient_id=${widget.patientId}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            kickCount = data['kick_count'];
          });
        } else {
          setState(() {
            error = data['message'];
          });
        }
      } else {
        setState(() {
          error = 'Failed to fetch the kick count';
        });
      }
    } catch (e) {
      setState(() {
        error = 'Failed to fetch the kick count';
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Function to update the kick count (increment or decrement)
  Future<void> updateKickCount(String action) async {
    if (!isEligibleToCount()) {
      showDialog(
          context: context,
          builder: (context) => AlertDialog(
                title: const Text("Eligibility Error"),
                content: const Text(
                    "You can only enter kick counts after 20 weeks of pregnancy."),
                actions: [
                  TextButton(
                    child: const Text("OK"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      var request = http.MultipartRequest(
          'POST', Uri.parse('${Urils.Url}/Eeruyir/kickcount.php'));
      request.fields['patient_id'] = widget.patientId;
      request.fields['action'] = action;

      var response = await request.send();
      if (response.statusCode == 200) {
        var responseData = await response.stream.bytesToString();
        var data = jsonDecode(responseData);

        if (data['status'] == 'success') {
          setState(() {
            kickCount = data['kick_count'];
          });
        } else {
          setState(() {
            error = data['message'];
          });
        }
      } else {
        setState(() {
          error = 'Failed to update the kick count';
        });
      }
    } catch (e) {
      setState(() {
        error = 'Failed to update the kick count';
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Baby Kick Count',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: Center(
        child: isLoading
            ? const CircularProgressIndicator()
            : error.isNotEmpty
                ? Text(
                    error,
                    style: const TextStyle(color: Colors.red),
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Current Kick Count: $kickCount',
                        style: const TextStyle(fontSize: 20),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () => updateKickCount('increment'),
                        child: const Text('Increment'),
                      ),
                      ElevatedButton(
                        onPressed: () => updateKickCount('decrement'),
                        child: const Text('Decrement'),
                      ),
                      if (!isEligibleToCount())
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 10.0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.grey[200], // Neutral background
                              borderRadius: BorderRadius.circular(10.0),
                              border: Border.all(
                                  color: Colors.red,
                                  width: 1), // Red border for emphasis
                            ),
                            padding: const EdgeInsets.all(10.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(
                                  Icons.warning,
                                  color: Colors.red, // Red warning icon
                                  size: 24,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: 'Warning: ',
                                          style: const TextStyle(
                                            color:
                                                Colors.red, // Red for emphasis
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        TextSpan(
                                          text:
                                              'Kick counts can be recorded after 20 weeks of pregnancy.',
                                          style: const TextStyle(
                                            color: Colors
                                                .black, // Neutral text color
                                            fontSize: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
      ),
    );
  }
}
