import 'dart:convert';
import 'package:Eeruyir/SelectionScreen.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'uril.dart';

import 'package:Eeruyir/PresentObstetricHistoryScreen.dart';
import 'package:Eeruyir/PatientLoginScreen.dart';

class PatientDetailsScreen extends StatefulWidget {
  const PatientDetailsScreen({super.key});

  @override
  _PatientDetailsScreenState createState() => _PatientDetailsScreenState();
}

class _PatientDetailsScreenState extends State<PatientDetailsScreen> {
  String firstName = "";
  String lastName = "";
  String age = "";
  String education = "";
  String occupation = "";
  String phoneNumber = "";
  String bloodGroup = "";
  DateTime? lmpDate;
  DateTime? dueDate;
  bool showLmpDatePicker = false;
  bool showDueDatePicker = false;
  String abortionHistory = "";
  String relativeToHusband = "";
  String confirmationOfPregnancy = "";
  String weight = "";
  String obstetricScore = "";
  String maritalStatus = "";
  String Height = "";

  void handleLmpDateChange(DateTime? date) {
    if (date == null || date.isAfter(DateTime.now())) {
      _showAlert("Invalid Date", "LMP date cannot be in the future.");
      return;
    }

    setState(() {
      lmpDate = date;
      dueDate = lmpDate?.add(const Duration(days: 280));
    });
  }

  void handleDueDateChange(DateTime? date) {
    setState(() {
      dueDate = date;
      if (date != null) {
        lmpDate = date.subtract(const Duration(days: 280));
      }
    });
  }

  void handleSave() async {
    // Check if all required fields are filled
    if ([
      firstName,
      lastName,
      age,
      education,
      occupation,
      phoneNumber,
      bloodGroup,
      lmpDate?.toString(),
      dueDate?.toString(),
      abortionHistory,
      relativeToHusband,
      confirmationOfPregnancy,
      weight,
      obstetricScore,
      maritalStatus,
      Height,
    ].any((element) => element?.isEmpty ?? true)) {
      _showAlert("Incomplete Form", "Please fill out all required fields.");
      return;
    }

    // Validate phone number
    if (!isValidPhoneNumber(phoneNumber)) {
      _showAlert(
          "Invalid Phone Number", "Phone number should be exactly 10 digits.");
      return;
    }

    // Validate age
    if (int.tryParse(obstetricScore) != 1 ||
        confirmationOfPregnancy == "No" ||
        !(int.tryParse(age) != null &&
            int.parse(age) >= 18 &&
            int.parse(age) <= 35) ||
        abortionHistory == "Yes" ||
        (double.tryParse(Height) != null && double.parse(Height) < 145)) {
      _showAlert(
        "Not Eligible",
        "Based on your details, eligibility requirements are not met.",
        onDismiss: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const SelectionScreen()),
          );
        },
      );
      return;
    }

    // Prepare the data to be sent
    final data = {
      "firstName": firstName,
      "lastName": lastName,
      "age": age,
      "education": education,
      "occupation": occupation,
      "phoneNumber": phoneNumber,
      "bloodGroup": bloodGroup,
      "lmpDate":
          lmpDate != null ? DateFormat('yyyy-MM-dd').format(lmpDate!) : null,
      "dueDate":
          dueDate != null ? DateFormat('yyyy-MM-dd').format(dueDate!) : null,
      "abortionHistory": abortionHistory,
      "relativeToHusband": relativeToHusband,
      "confirmationOfPregnancy": confirmationOfPregnancy,
      "weight": weight,
      "obstetricScore": obstetricScore,
      "maritalStatus": maritalStatus,
      "Height": Height,
    };

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/createpatients.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(data),
      );
      print("API response status: ${response.statusCode}");
      print("API response body: ${response.body}");
      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        print("navigate body: $responseData");
        if (responseData['message'] == 'Patient details saved successfully.') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PresentObstetricHistoryScreen(
                patientId: responseData['patient_id'],
              ),
            ),
          );
        } else {
          throw Exception(responseData['message'] ?? 'Unknown error');
        }
      } else {
        throw Exception(
            'Failed to save patient details. Status code: ${response.statusCode}');
      }
    } catch (e) {
      _showAlert("", "${e.toString()}");
    }
  }

  bool isValidPhoneNumber(String number) {
    return RegExp(r'^\d{10}$').hasMatch(number);
  }

  void _showAlert(String title, String message, {VoidCallback? onDismiss}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            child: const Text("OK"),
            onPressed: () {
              Navigator.of(context).pop();
              if (onDismiss != null) onDismiss();
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Patient Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildTextField(
                  "First Name", (value) => setState(() => firstName = value)),
              _buildTextField(
                  "Last Name", (value) => setState(() => lastName = value)),
              _buildTextField("Age", (value) => setState(() => age = value),
                  keyboardType: TextInputType.number),
              _buildTextField(
                  "Education", (value) => setState(() => education = value)),
              _buildTextField(
                  "Occupation", (value) => setState(() => occupation = value)),
              _buildTextField("Phone Number",
                  (value) => setState(() => phoneNumber = value),
                  keyboardType: TextInputType.phone),
              _buildDropdown(
                  "Blood Group",
                  ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'],
                  (value) => setState(() => bloodGroup = value!)),
              _buildDatePicker("LMP Date", lmpDate, handleLmpDateChange),
              _buildDatePicker("Due Date", dueDate, handleDueDateChange),
              _buildDropdown("Abortion History", ['Yes', 'No'],
                  (value) => setState(() => abortionHistory = value!)),
              _buildDropdown("Relative to Husband", ['Yes', 'No'],
                  (value) => setState(() => relativeToHusband = value!)),
              _buildDropdown("Confirmation of Pregnancy", ['Yes', 'No'],
                  (value) => setState(() => confirmationOfPregnancy = value!)),
              _buildTextField(
                  "Weight", (value) => setState(() => weight = value),
                  keyboardType: TextInputType.number),
              _buildTextField("Obstetric Score",
                  (value) => setState(() => obstetricScore = value),
                  keyboardType: TextInputType.number),
              _buildDropdown(
                  "Marital Status",
                  ['Single', 'Married', 'Divorced', 'Widowed'],
                  (value) => setState(() => maritalStatus = value!)),
              _buildTextField(
                  "Height(cm)", (value) => setState(() => Height = value),
                  keyboardType: TextInputType.number),
              ElevatedButton(
                onPressed: handleSave,
                child: const Text("Save"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, Function(String) onChanged,
      {TextInputType keyboardType = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        onChanged: onChanged,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _buildDropdown(
      String label, List<String> options, Function(String?) onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: DropdownButtonFormField<String>(
        onChanged: onChanged,
        items: options
            .map((option) =>
                DropdownMenuItem<String>(value: option, child: Text(option)))
            .toList(),
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _buildDatePicker(
      String label, DateTime? selectedDate, Function(DateTime?) onDateChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: InkWell(
        onTap: () async {
          DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: selectedDate ?? DateTime.now(),
            firstDate: DateTime(1900),
            lastDate: DateTime(2100),
          );
          if (pickedDate != null) {
            onDateChanged(pickedDate);
          }
        },
        child: AbsorbPointer(
          child: TextField(
            controller: TextEditingController(
              text: selectedDate != null
                  ? DateFormat('yyyy-MM-dd').format(selectedDate)
                  : '',
            ),
            decoration: InputDecoration(
              labelText: label,
              border: const OutlineInputBorder(),
            ),
          ),
        ),
      ),
    );
  }
}
