import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter/services.dart';
import 'dart:async';

import 'package:Eeruyir/SelectionScreen.dart';

class UserSelectionScreen extends StatefulWidget {
  final VoidCallback onPatientSelected;

  // Constructor to accept the callback
  const UserSelectionScreen({super.key, required this.onPatientSelected});

  @override
  _UserSelectionScreenState createState() => _UserSelectionScreenState();
}

class _UserSelectionScreenState extends State<UserSelectionScreen> {
  bool _fontsLoaded = false;

  @override
  void initState() {
    super.initState();
    loadFonts();
    Timer(const Duration(seconds: 3), () {
      // Navigate to SelectionScreen and call the callback
      widget.onPatientSelected(); // Trigger the callback
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) =>
              const SelectionScreen(), // Direct call to SelectionScreen class
        ),
      );
    });
  }

  Future<void> loadFonts() async {
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    setState(() {
      _fontsLoaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_fontsLoaded) {
      return const Center(
          child: CircularProgressIndicator()); // Show a loading spinner
    }

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF00c6ff), Color(0xFF0072ff)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  alignment: Alignment.center,
                  child: SvgPicture.string(
                    '''
                    <svg height="${MediaQuery.of(context).size.height * 0.125}" width="${MediaQuery.of(context).size.width * 0.75}">
                      <defs>
                        <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0" stop-color="#2DC2D7" />
                          <stop offset="0.5" stop-color="#0072ff" />
                          <stop offset="1" stop-color="#9933ff" />
                        </linearGradient>
                      </defs>
                      <text fill="white" font-size="${MediaQuery.of(context).size.width * 0.125}" font-family="Roboto" x="${MediaQuery.of(context).size.width * 0.375}" y="${MediaQuery.of(context).size.height * 0.0875}" text-anchor="middle">Eeruyir</text>
                    </svg>
                    ''',
                    width: MediaQuery.of(context).size.width * 0.75,
                    height: MediaQuery.of(context).size.height * 0.125,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
