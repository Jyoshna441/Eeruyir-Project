import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/PatientProfile.dart';
import 'dart:convert';

import 'uril.dart';

class OutcomeTab extends StatefulWidget {
  const OutcomeTab({super.key});

  @override
  _OutcomeTabState createState() => _OutcomeTabState();
}

class _OutcomeTabState extends State<OutcomeTab> {
  Map<String, dynamic> data = {
    'patients': [],
    'normalPatients': {'count': 0, 'patients': []},
    'lsPatients': {'count': 0, 'patients': []},
    'exercisePatients': [],
    'exerciseNormalPatients': {'count': 0, 'patients': []},
    'exerciseLsPatients': {'count': 0, 'patients': []},
  };

  Map<String, bool> sectionsVisibility = {
    'showAllPatients': false,
    'showNormalPatients': false,
    'showLsPatients': false,
  };

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final response =
          await http.get(Uri.parse('${Urils.Url}/Eeruyir/fetch_outcomes.php'));
      final result = json.decode(response.body);
      setState(() {
        data = {
          'patients': result['patients'] ?? [],
          'normalPatients':
              result['normalPatients'] ?? {'count': 0, 'patients': []},
          'lsPatients': result['lsPatients'] ?? {'count': 0, 'patients': []},
          'exercisePatients': result['exercisePatients'] ?? [],
          'exerciseNormalPatients':
              result['exerciseNormalPatients'] ?? {'count': 0, 'patients': []},
          'exerciseLsPatients':
              result['exerciseLsPatients'] ?? {'count': 0, 'patients': []},
        };
      });
    } catch (error) {
      print('Error fetching data: $error');
    }
  }

  void toggleSectionVisibility(String section) {
    setState(() {
      sectionsVisibility[section] =
          !sectionsVisibility[section]!; // Toggle visibility of the section
    });
  }

  void handleViewProfile(int patientId) {
    // Navigate to patient profile screen
    // Implement navigation logic here
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text(
          'Outcome of Delivery',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Column(
          children: [
            // All Patients Section
            Section(
              title: "Total Patients Delivered",
              countText:
                  "Total Patients Exercised at least 20 days: ${data['exercisePatients'].length}",
              data: data['patients'],
              isVisible: sectionsVisibility['showAllPatients']!,
              toggleVisibility: () =>
                  toggleSectionVisibility('showAllPatients'),
              renderItem: renderPatientItem,
            ),

            // Normal Delivery Section
            Section(
              title: "Normal Vaginal Delivery",
              countText:
                  "Normal Patients Exercised at least 20 days: ${data['exerciseNormalPatients']['count']}",
              data: data['normalPatients']['patients'],
              isVisible: sectionsVisibility['showNormalPatients']!,
              toggleVisibility: () =>
                  toggleSectionVisibility('showNormalPatients'),
              renderItem: renderPatientItem,
            ),

            // LSCS Delivery Section
            Section(
              title: "LSCS Delivery",
              countText:
                  "LSCS Patients Exercised at least 20 days: ${data['exerciseLsPatients']['count']}",
              data: data['lsPatients']['patients'],
              isVisible: sectionsVisibility['showLsPatients']!,
              toggleVisibility: () => toggleSectionVisibility('showLsPatients'),
              renderItem: renderPatientItem,
            ),
          ],
        ),
      ),
    );
  }

  Widget renderPatientItem(Map<String, dynamic> item) {
    return GestureDetector(
      onTap: () => handleViewProfile(item['patient_id']),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  // Navigate to PatientProfile and pass the patientId
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PatientProfile(
                        patientId: item['patient_id'],
                      ),
                    ),
                  );
                },
                child: Text(
                  'Patient ID: ${item['patient_id']}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF0072FF),
                    decoration: TextDecoration
                        .underline, // Optional: to indicate it's clickable
                  ),
                ),
              ),
              Text(
                '${item['firstName']} ${item['lastName']}',
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Section extends StatelessWidget {
  final String title;
  final String countText;
  final List<dynamic> data;
  final bool isVisible;
  final VoidCallback toggleVisibility;
  final Function(Map<String, dynamic>) renderItem;

  const Section({
    super.key,
    required this.title,
    required this.countText,
    required this.data,
    required this.isVisible,
    required this.toggleVisibility,
    required this.renderItem,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: toggleVisibility,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey[300]!)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '$title:',
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                ),
                Icon(
                  isVisible ? Icons.arrow_drop_up : Icons.arrow_drop_down,
                  color: Colors.black,
                ),
              ],
            ),
          ),
        ),
        if (isVisible) ...[
          if (data.isNotEmpty)
            ListView.builder(
              itemCount: data.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) => renderItem(data[index]),
            )
          else
            Center(
                child: Text(
              'No $title found',
              style: TextStyle(color: Colors.grey[600], fontSize: 16),
            )),
          Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 24, left: 10),
            child: Text(
              countText,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),
            ),
          ),
        ],
      ],
    );
  }
}
