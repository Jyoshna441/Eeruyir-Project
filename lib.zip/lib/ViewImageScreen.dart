import 'package:flutter/material.dart';

class ViewImageScreen extends StatelessWidget {
  final String imageUri;

  const ViewImageScreen({super.key, required this.imageUri});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Image.network(
          imageUri,
          fit: BoxFit.contain,
          width: double.infinity,
          height: double.infinity,
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).pop(); // Close the screen
        },
        backgroundColor: Colors.blue,
        child: const Icon(Icons.close),
      ),
    );
  }
}
