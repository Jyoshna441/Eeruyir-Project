import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:Eeruyir/uril.dart';
import 'package:file_picker/file_picker.dart';
import 'package:Eeruyir/DownloadScreen.dart';

class DoctorDetailsScreen extends StatefulWidget {
  final String username;
  const DoctorDetailsScreen({super.key, required this.username});

  @override
  _DoctorDetailsScreenState createState() => _DoctorDetailsScreenState();
}

class _DoctorDetailsScreenState extends State<DoctorDetailsScreen> {
  Map<String, dynamic>? doctorDetails;
  bool isLoading = true;
  String error = '';

  @override
  void initState() {
    super.initState();
    fetchDoctorDetails();
  }

  Future<void> fetchDoctorDetails() async {
    try {
      final response = await http.get(
        Uri.parse(
            '${Urils.Url}/Eeruyir/doctorprofile.php?username=${widget.username}'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);

        if (data['success'] == true) {
          setState(() {
            doctorDetails = data['data'];
            isLoading = false;
          });
        } else {
          setState(() {
            error = data['message'] ?? 'Unknown error occurred';
            isLoading = false;
          });
        }
      } else {
        throw Exception('Failed to load data: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        error = e.toString();
        isLoading = false;
      });
    }
  }

  Future<void> requestPermission() async {
    if (Platform.isAndroid) {
      final storagePermission = await Permission.storage.request();
      if (!storagePermission.isGranted) {
        final manageStoragePermission =
            await Permission.manageExternalStorage.request();
        if (!manageStoragePermission.isGranted) {
          await openAppSettings();
        }
      }
    }
  }

  Future<void> downloadCSV(String fileName) async {
    try {
      // Request permissions
      await requestPermission();

      // Let the user select a directory
      String? selectedPath = await FilePicker.platform.getDirectoryPath();
      if (selectedPath != null) {
        // If the user selected a directory
        final filePath = '$selectedPath/$fileName.csv';
        final file = File(filePath);

        // Download data and write to file
        final response =
            await http.get(Uri.parse('${Urils.Url}/Eeruyir/csvdata.php'));
        if (response.statusCode == 200) {
          await file.writeAsBytes(response.bodyBytes);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('CSV downloaded to $filePath')),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to download CSV')),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No directory selected')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Doctor Profile',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.download, color: Colors.white),
            onPressed: () {
              // Navigate to the DownloadScreen
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DownloadScreen()),
              );
            },
          ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : error.isNotEmpty
              ? Center(
                  child: Text(
                    'Error: $error',
                    style: const TextStyle(color: Colors.red, fontSize: 16),
                  ),
                )
              : doctorDetails == null || doctorDetails!.isEmpty
                  ? const Center(child: Text('No data available'))
                  : Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: ListView(
                        children: [
                          Card(
                            elevation: 5,
                            margin: const EdgeInsets.symmetric(vertical: 8.0),
                            child: ListTile(
                              leading: Icon(Icons.person,
                                  color:
                                      const Color.fromARGB(255, 166, 165, 220)),
                              title: Text(
                                'Name: ${doctorDetails!['name'] ?? 'N/A'}',
                                style: const TextStyle(fontSize: 15),
                              ),
                            ),
                          ),
                          Card(
                            elevation: 5,
                            margin: const EdgeInsets.symmetric(vertical: 8.0),
                            child: ListTile(
                              leading: Icon(Icons.email,
                                  color:
                                      const Color.fromARGB(255, 166, 165, 220)),
                              title: Text(
                                'Email: ${doctorDetails!['email'] ?? 'N/A'}',
                                style: const TextStyle(fontSize: 15),
                              ),
                            ),
                          ),
                          Card(
                            elevation: 5,
                            margin: const EdgeInsets.symmetric(vertical: 8.0),
                            child: ListTile(
                              leading: Icon(Icons.phone,
                                  color:
                                      const Color.fromARGB(255, 166, 165, 220)),
                              title: Text(
                                'Phone Number: ${doctorDetails!['phonenumber'] ?? 'N/A'}',
                                style: const TextStyle(fontSize: 15),
                              ),
                            ),
                          ),
                          Card(
                            elevation: 5,
                            margin: const EdgeInsets.symmetric(vertical: 8.0),
                            child: ListTile(
                              leading: Icon(Icons.medical_services,
                                  color:
                                      const Color.fromARGB(255, 166, 165, 220)),
                              title: Text(
                                'Specialization: ${doctorDetails!['specialization'] ?? 'N/A'}',
                                style: const TextStyle(fontSize: 15),
                              ),
                            ),
                          ),
                          Card(
                            elevation: 5,
                            margin: const EdgeInsets.symmetric(vertical: 8.0),
                            child: ListTile(
                              leading: Icon(Icons.work,
                                  color:
                                      const Color.fromARGB(255, 166, 165, 220)),
                              title: Text(
                                'Experience: ${doctorDetails!['experience'] ?? 'N/A'} year',
                                style: const TextStyle(fontSize: 15),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
    );
  }
}
