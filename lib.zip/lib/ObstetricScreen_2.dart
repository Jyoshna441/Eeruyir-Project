import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:Eeruyir/uril.dart';
import 'package:Eeruyir/MedicalHistory.dart';

class ObstetricScreen2 extends StatefulWidget {
  final String patientId;

  const ObstetricScreen2({super.key, required this.patientId});

  @override
  _ObstetricScreen2State createState() => _ObstetricScreen2State();
}

class _ObstetricScreen2State extends State<ObstetricScreen2> {
  String additionalMedicalConditions = '';

  // Existing variables for other questions
  String anomalousFetus = '';
  String jaundice = '';
  String activeTB = '';
  String liverDisease = '';
  String autoimmuneDisorder = '';
  String waterLevelChange = '';

  Future<void> handleSubmit() async {
    if (anomalousFetus.isEmpty ||
        jaundice.isEmpty ||
        activeTB.isEmpty ||
        liverDisease.isEmpty ||
        autoimmuneDisorder.isEmpty ||
        waterLevelChange.isEmpty ||
        additionalMedicalConditions.isEmpty) {
      showAlert("Error", "Please answer all the questions.");
      return;
    }

    List<Map<String, dynamic>> responses = [
      {'categoryId': 1, 'questionId': 13, 'answer': anomalousFetus},
      {'categoryId': 1, 'questionId': 14, 'answer': jaundice},
      {'categoryId': 1, 'questionId': 15, 'answer': activeTB},
      {'categoryId': 1, 'questionId': 16, 'answer': liverDisease},
      {'categoryId': 1, 'questionId': 17, 'answer': autoimmuneDisorder},
      {'categoryId': 1, 'questionId': 18, 'answer': waterLevelChange},
      {
        'categoryId': 1,
        'questionId': 19,
        'answer': additionalMedicalConditions
      },
    ];

    try {
      final response = await http.post(
        Uri.parse("${Urils.Url}/Eeruyir/Categoriesanswer.php"),
        headers: {'Content-Type': 'application/json'},
        body: json
            .encode({'patientId': widget.patientId, 'responses': responses}),
      );

      final result = json.decode(response.body);

      if (response.statusCode == 200) {
        showAlert('Success',
            'Patient details saved successfully. Patient ID: ${result['patientId']}');
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                MedicalHistory(patientId: result['patientId']),
          ),
        );
      } else {
        showAlert("Error", result['message'] ?? 'Failed to submit data');
      }
    } catch (error) {
      showAlert("Error", "Failed to submit data");
      print("Error submitting data: $error");
    }
  }

  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK')),
        ],
      ),
    );
  }

  // You can add a method to build a question as before, but now with these new questions.
  Widget buildQuestion(String question, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(question, style: const TextStyle(fontSize: 16)),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('Yes'),
                value: 'yes',
                groupValue: (question ==
                        'Confirm whether your scan findings mentioned or if your doctor informed you about the possibility of your baby being an anomalous fetus (abnormal baby)?')
                    ? anomalousFetus
                    : (question == 'Do you have Jaundice in current pregnancy?')
                        ? jaundice
                        : (question ==
                                'Do you have Active TB infection in current pregnancy?')
                            ? activeTB
                            : (question ==
                                    'Do you have ANY LIVER DISEASE in current pregnancy?')
                                ? liverDisease
                                : (question ==
                                        'Do you have ANY AUTO IMMUNE DISORDER (Eg: SLE, APLA, Rheumatoid arthritis, etc) in current pregnancy?')
                                    ? autoimmuneDisorder
                                    : (question ==
                                            'Has your doctor told that your water level has increased or decreased?')
                                        ? waterLevelChange
                                        : '',
                onChanged: onChanged,
              ),
            ),
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('No'),
                value: 'no',
                groupValue: (question ==
                        'Confirm whether your scan findings mentioned or if your doctor informed you about the possibility of your baby being an anomalous fetus (abnormal baby)?')
                    ? anomalousFetus
                    : (question == 'Do you have Jaundice in current pregnancy?')
                        ? jaundice
                        : (question ==
                                'Do you have Active TB infection in current pregnancy?')
                            ? activeTB
                            : (question ==
                                    'Do you have ANY LIVER DISEASE in current pregnancy?')
                                ? liverDisease
                                : (question ==
                                        'Do you have ANY AUTO IMMUNE DISORDER (Eg: SLE, APLA, Rheumatoid arthritis, etc) in current pregnancy?')
                                    ? autoimmuneDisorder
                                    : (question ==
                                            'Has your doctor told that your water level has increased or decreased?')
                                        ? waterLevelChange
                                        : '',
                onChanged: onChanged,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  // Adding a new widget for the text input question (ID 19)
  Widget buildTextInputQuestion(
      String question, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(question, style: const TextStyle(fontSize: 16)),
        TextField(
          onChanged: onChanged,
          decoration: const InputDecoration(
            hintText: 'Enter your answer here',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Obstetric History',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildQuestion(
                    'Confirm whether your scan findings mentioned or if your doctor informed you about the possibility of your baby being an anomalous fetus (abnormal baby)?',
                    (value) => setState(() => anomalousFetus = value ?? '')),
                buildQuestion('Do you have Jaundice in current pregnancy?',
                    (value) => setState(() => jaundice = value ?? '')),
                buildQuestion(
                    'Do you have Active TB infection in current pregnancy?',
                    (value) => setState(() => activeTB = value ?? '')),
                buildQuestion(
                    'Do you have ANY LIVER DISEASE in current pregnancy?',
                    (value) => setState(() => liverDisease = value ?? '')),
                buildQuestion(
                    'Do you have ANY AUTO IMMUNE DISORDER (Eg: SLE, APLA, Rheumatoid arthritis, etc) in current pregnancy?',
                    (value) =>
                        setState(() => autoimmuneDisorder = value ?? '')),
                buildQuestion(
                    'Has your doctor told that your water level has increased or decreased?',
                    (value) => setState(() => waterLevelChange = value ?? '')),
                // New question with text input for medical conditions not mentioned
                buildTextInputQuestion(
                    'Do you have any medical conditions that haven\'t been mentioned before?',
                    (value) => setState(
                        () => additionalMedicalConditions = value ?? '')),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 30),
                    textStyle: const TextStyle(fontSize: 16),
                  ),
                  onPressed: handleSubmit,
                  child: const Text('Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
