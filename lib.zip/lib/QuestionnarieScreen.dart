import 'package:flutter/material.dart';
// Ensure to use a linear gradient package

class QuestionnaireScreen extends StatelessWidget {
  final bool? visitedObstetricScreen4;
  final bool? visitedMedicalHistory3;
  final bool? visitedSurgicalHistory2;
  final bool? visitedTraumaHistory;
  final int patientId;

  const QuestionnaireScreen({
    super.key,
    required this.visitedObstetricScreen4,
    required this.visitedMedicalHistory3,
    required this.visitedSurgicalHistory2,
    required this.visitedTraumaHistory,
    required this.patientId,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF00c6ff), Color(0xFF0072ff)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              const Text(
                'Questionnaires',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  shadows: [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(1, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              QuestionnaireButton(
                text: "Present Obstetric History",
                icon: "📋",
                onPress: () {
                  Navigator.pushNamed(
                    context,
                    'PresentObstetricHistoryScreen',
                    arguments: {'patientId': patientId},
                  );
                },
                visited: visitedObstetricScreen4,
              ),
              QuestionnaireButton(
                text: "Medical History",
                icon: "🩺",
                onPress: () {
                  Navigator.pushNamed(
                    context,
                    'MedicalHistory',
                    arguments: {'visitedMedicalHistory3': true},
                  );
                },
                visited: visitedMedicalHistory3,
              ),
              QuestionnaireButton(
                text: "Surgical History",
                icon: "🏥",
                onPress: () {
                  Navigator.pushNamed(context, 'SurgicalHistory');
                },
                visited: visitedSurgicalHistory2,
              ),
              QuestionnaireButton(
                text: "Trauma History",
                icon: "⚕️",
                onPress: () {
                  Navigator.pushNamed(context, 'TraumaHistory');
                },
                visited: visitedTraumaHistory,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class QuestionnaireButton extends StatelessWidget {
  final String text;
  final String icon;
  final VoidCallback onPress;
  final bool? visited;

  const QuestionnaireButton({
    super.key,
    required this.text,
    required this.icon,
    required this.onPress,
    required this.visited,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPress,
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        constraints: const BoxConstraints(maxWidth: 350),
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 25),
        margin: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: visited == true
              ? const Color(0xFF00c6ff).withOpacity(0.87)
              : const Color(0xFFFFFFFF).withOpacity(0.87),
          borderRadius: BorderRadius.circular(25),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(0, 2),
              blurRadius: 5,
              spreadRadius: 0,
            ),
          ],
          border: Border.all(color: const Color(0xFFFFFFFF), width: 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              text,
              style: const TextStyle(
                color: Color(0xFF0072ff),
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(
                width: 10), // This will add space between the text and the icon
            Text(
              icon,
              style: const TextStyle(
                fontSize: 24,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
