import 'package:flutter/material.dart';
import 'package:Eeruyir/PatientSignup.dart';

class TermsScreen extends StatefulWidget {
  const TermsScreen({super.key});

  @override
  _TermsScreenState createState() => _TermsScreenState();
}

class _TermsScreenState extends State<TermsScreen> {
  bool isFirstChecked = false;
  bool isSecondChecked = false;

  void handleAgree(BuildContext context) {
    if (isFirstChecked && isSecondChecked) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const PatientSignup(),
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Error'),
          content: const Text('Please agree to both terms and conditions.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
              },
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Terms and Conditions',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: const Color(0xFF007DFE),
        automaticallyImplyLeading: false,
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
            horizontal: width * 0.04, vertical: height * 0.02),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Header Image
              SizedBox(
                width: width,
                height: height * 0.25,
                child: Image.asset(
                  'assets/bg2.png', // Update the asset path as needed
                  fit: BoxFit.contain,
                ),
              ),

              // Title
              Container(
                width: width,
                margin: EdgeInsets.symmetric(vertical: height * 0.02),
                alignment: Alignment.center,
                child: Text(
                  'Please Read Carefully',
                  style: TextStyle(
                    fontSize: width * 0.06,
                    fontWeight: FontWeight.bold,
                    color: const Color.fromARGB(255, 231, 57, 4),
                  ),
                ),
              ),

              // Content with Checkboxes
              Container(
                width: width,
                padding: EdgeInsets.all(height * 0.02),
                decoration: BoxDecoration(
                  color: const Color(0xFFF7F7F7),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                margin: EdgeInsets.only(bottom: height * 0.03),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Checkbox(
                          value: isFirstChecked,
                          onChanged: (bool? value) {
                            setState(() {
                              isFirstChecked = value!;
                            });
                          },
                        ),
                        Expanded(
                          child: Text(
                            'I hereby declare that I am voluntarily viewing this video, and the responses I provide are true to the best of my knowledge.',
                            style: TextStyle(
                              fontSize: width * 0.045,
                              height: 1.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Checkbox(
                          value: isSecondChecked,
                          onChanged: (bool? value) {
                            setState(() {
                              isSecondChecked = value!;
                            });
                          },
                        ),
                        Expanded(
                          child: Text(
                            'I accept all the terms and conditions.',
                            style: TextStyle(
                              fontSize: width * 0.045,
                              height: 1.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Agree Button
              SizedBox(
                width: width * 0.8,
                height: height * 0.06,
                child: ElevatedButton(
                  onPressed: () => handleAgree(context),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    backgroundColor: const Color(0xFF007DFE),
                  ),
                  child: const Text(
                    'Agree and Continue',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
