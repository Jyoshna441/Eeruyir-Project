import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/ObstetricScreen_2.dart';
import 'dart:convert';

import 'uril.dart';

class ObstetricScreen1 extends StatefulWidget {
  final String patientId;

  const ObstetricScreen1({super.key, required this.patientId});

  @override
  _ObstetricScreen1State createState() => _ObstetricScreen1State();
}

class _ObstetricScreen1State extends State<ObstetricScreen1> {
  // Add variables for new questions
  String anemia = '';
  String seizureDisorder = '';
  String hypothyroid = '';
  String hyperthyroid = '';
  String cervicalIncompetence = '';
  String hadCSection = '';

  Future<void> handleSubmit() async {
    if (anemia.isEmpty ||
        seizureDisorder.isEmpty ||
        hypothyroid.isEmpty ||
        hyperthyroid.isEmpty ||
        cervicalIncompetence.isEmpty ||
        hadCSection.isEmpty) {
      showAlert("Error", "Please answer all the questions.");
      return;
    }

    List<Map<String, dynamic>> responses = [
      {'categoryId': 1, 'questionId': 7, 'answer': anemia},
      {'categoryId': 1, 'questionId': 8, 'answer': seizureDisorder},
      {'categoryId': 1, 'questionId': 9, 'answer': hypothyroid},
      {'categoryId': 1, 'questionId': 10, 'answer': hyperthyroid},
      {'categoryId': 1, 'questionId': 11, 'answer': cervicalIncompetence},
      {'categoryId': 1, 'questionId': 12, 'answer': hadCSection},
    ];

    try {
      final response = await http.post(
        Uri.parse("${Urils.Url}/Eeruyir/Categoriesanswer.php"),
        headers: {'Content-Type': 'application/json'},
        body: json
            .encode({'patientId': widget.patientId, 'responses': responses}),
      );

      final result = json.decode(response.body);

      if (response.statusCode == 200) {
        showAlert('Success',
            'Patient details saved successfully. Patient ID: ${result['patientId']}');
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                ObstetricScreen2(patientId: result['patientId']),
          ),
        );
      } else {
        showAlert("Error", result['message'] ?? 'Failed to submit data');
      }
    } catch (error) {
      showAlert("Error", "Failed to submit data");
      print("Error submitting data: $error");
    }
  }

  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK')),
        ],
      ),
    );
  }

  // You can add a method to build a question as before, but now with these new questions.
  Widget buildQuestion(String question, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(question, style: const TextStyle(fontSize: 16)),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('Yes'),
                value: 'yes',
                groupValue: (question ==
                        'Have your doctor told you that you are having Anemia/does your blood tests suggest that you have anemia?(decreased hemoglobin)')
                    ? anemia
                    : (question ==
                            'Do you have Seizure disorder (i.e. fits) in current pregnancy?')
                        ? seizureDisorder
                        : (question ==
                                'Do you have Hypothyroid in current pregnancy?')
                            ? hypothyroid
                            : (question ==
                                    'Do you have Hyperthyroid in current pregnancy?')
                                ? hyperthyroid
                                : (question ==
                                        'Did your doctor say the length of your cervix is short? (cervical incompetence)')
                                    ? cervicalIncompetence
                                    : (question ==
                                            'Have they put a stitch in cervix in current pregnancy?')
                                        ? hadCSection
                                        : '',
                onChanged: onChanged,
              ),
            ),
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('No'),
                value: 'no',
                groupValue: (question ==
                        'Have your doctor told you that you are having Anemia/does your blood tests suggest that you have anemia?(decreased hemoglobin)')
                    ? anemia
                    : (question ==
                            'Do you have Seizure disorder (i.e. fits) in current pregnancy?')
                        ? seizureDisorder
                        : (question ==
                                'Do you have Hypothyroid in current pregnancy?')
                            ? hypothyroid
                            : (question ==
                                    'Do you have Hyperthyroid in current pregnancy?')
                                ? hyperthyroid
                                : (question ==
                                        'Did your doctor say the length of your cervix is short? (cervical incompetence)')
                                    ? cervicalIncompetence
                                    : (question ==
                                            'Have they put a stitch in cervix in current pregnancy?')
                                        ? hadCSection
                                        : '',
                onChanged: onChanged,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Obstetric History',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildQuestion(
                    'Have your doctor told you that you are having Anemia/does your blood tests suggest that you have anemia?(decreased hemoglobin)',
                    (value) => setState(() => anemia = value ?? '')),
                buildQuestion(
                    'Do you have Seizure disorder (i.e. fits) in current pregnancy?',
                    (value) => setState(() => seizureDisorder = value ?? '')),
                buildQuestion('Do you have Hypothyroid in current pregnancy?',
                    (value) => setState(() => hypothyroid = value ?? '')),
                buildQuestion('Do you have Hyperthyroid in current pregnancy?',
                    (value) => setState(() => hyperthyroid = value ?? '')),
                buildQuestion(
                    'Did your doctor say the length of your cervix is short? (cervical incompetence)',
                    (value) =>
                        setState(() => cervicalIncompetence = value ?? '')),
                buildQuestion(
                    'Have they put a stitch in cervix in current pregnancy?',
                    (value) => setState(() => hadCSection = value ?? '')),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 30),
                    textStyle: const TextStyle(fontSize: 16),
                  ),
                  onPressed: handleSubmit,
                  child: const Text('Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
