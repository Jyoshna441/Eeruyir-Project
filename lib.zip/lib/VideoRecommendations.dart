import 'package:flutter/material.dart';
import 'package:Eeruyir/uril.dart';
import 'package:video_player/video_player.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class VideoRecommendations extends StatefulWidget {
  final String trimester;
  final String patientId;

  const VideoRecommendations(
      {super.key, required this.trimester, required this.patientId});

  @override
  _VideoRecommendationsState createState() => _VideoRecommendationsState();
}

class _VideoRecommendationsState extends State<VideoRecommendations> {
  List<Map<String, dynamic>> videos = [];
  int points = 0;
  List<int> completedVideos = [];
  bool showVideo = false;
  int currentVideoIndex = 0;
  late VideoPlayerController _controller;
  double rotationAngle = 0.0; // Rotation angle for the video
  bool showPoll = true; // State to control the visibility of the modal
  String selectedOption = '';
  bool showDisclaimer = true; // State for showing disclaimer
  @override
  void initState() {
    super.initState();
    fetchCompletedVideos();
    loadVideos();
  }

  void loadVideos() async {
    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/videos_retrive.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'trimester': widget.trimester}),
      );

      print('Response body U GET: ${response.body}'); // Debug log

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);
        if (jsonResponse['status'] == 'success') {
          print('Videos loaded successfully');
          final List<dynamic> videoData = jsonResponse['data'];

          // Group videos by trimester dynamically
          Map<String, List<Map<String, dynamic>>> groupedVideos = {
            '1st Trimester': [],
            '2nd Trimester': [],
            '3rd Trimester': []
          };

          for (var video in videoData) {
            int videoId = video['id'];
            if (videoId >= 1 && videoId <= 10) {
              groupedVideos['1st Trimester']?.add({
                'id': video['id'],
                'source': video['video_path'],
                'thumbnail': video['thumbnail'],
                'videoName': video['video_name'],
              });
            } else if (videoId >= 11 && videoId <= 24) {
              groupedVideos['2nd Trimester']?.add({
                'id': video['id'],
                'source': video['video_path'],
                'thumbnail': video['thumbnail'],
                'videoName': video['video_name'],
              });
            } else if (videoId >= 25) {
              groupedVideos['3rd Trimester']?.add({
                'id': video['id'],
                'source': video['video_path'],
                'thumbnail': video['thumbnail'],
                'videoName': video['video_name'],
              });
            }
          }

          // Assign videos to the `videos` variable
          setState(() {
            videos = groupedVideos[widget.trimester] ?? [];
          });
        } else {
          print('Failed to load videos: ${jsonResponse['status']}');
        }
      } else {
        print('Error fetching videos: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception caught while fetching videos: $e');
    }
  }

  Future<void> saveCompletionDate(int videoId) async {
    if (widget.patientId.isEmpty || widget.trimester.isEmpty) return;

    try {
      var response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/saveCompletionDate.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'patientId': widget.patientId,
          'trimester': widget.trimester,
          'videoId': videoId.toString(),
          'completionDate': DateTime.now().toIso8601String().split('T')[0],
        },
      );
      print("Response Status: ${response.statusCode}");
      print("Response Body: ${response.body}");
      if (response.statusCode != 200) {
        throw Exception('Network response was not ok');
      }
    } catch (error) {
      print('Error saving completion date: $error');
    }
  }

  Future<void> fetchCompletedVideos() async {
    try {
      var response = await http.get(Uri.parse(
          '${Urils.Url}/Eeruyir/getCompletedVideos.php?patient_id=${widget.patientId}'));
      var responseData = json.decode(response.body) as List;
      print("Response Status: ${response.statusCode}");
      print("Response Body: ${responseData}");
      setState(() {
        completedVideos = responseData.map((video) => video as int).toList();
      });
    } catch (error) {
      print('Error fetching completed videos: $error');
    }
  }

  Future<void> saveVideoProgress(int videoId) async {
    try {
      var response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/saveVideoProgress.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'patientId': widget.patientId,
          'videoId': videoId.toString(),
          'progress': 'completed',
          'trimester': widget.trimester,
          'completionDate': DateTime.now().toIso8601String().split('T')[0],
        },
      );
      print("Response Status: ${response.statusCode}");
      print("Response Body: ${response.body}");
      if (response.statusCode != 200) {
        throw Exception('Network response was not ok');
      }
    } catch (error) {
      print('Error saving video progress: $error');
    }
  }

  Future<void> recordMentalHealthData(String data) async {
    try {
      var response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/recordMentalHealthData.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'patientId': widget.patientId,
          'mentalHealth': data,
          'date': DateTime.now().toIso8601String(),
        },
      );
      print("Response Status: ${response.statusCode}");
      print("Response Body: ${response.body}");
      if (response.statusCode != 200) {
        throw Exception('Network response was not ok');
      }
    } catch (error) {
      print('Error recording mental health data: $error');
    }
  }

  void handleVideoEnd() async {
    int videoId = videos[currentVideoIndex]['id'];
    setState(() {
      completedVideos.add(videoId);
      points += 5;
      showVideo = false; // Hide the video after completion
    });

    // Save video progress and fetch updated completed videos
    await saveVideoProgress(videoId);
    await fetchCompletedVideos();

    // Show completion dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Task Completed'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pop();
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );

    // Check if the current day is Monday
    if (DateTime.now().weekday == DateTime.monday) {
      // Display the mental health poll
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Mental Health Poll'),
          content: const Text(
            'We’d like to know how you are feeling today. Please answer a few questions.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                // Close the current dialog
                Navigator.of(context).pop();

                // Open the detailed mental health poll
                _showMentalHealthPoll();
              },
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }

    // Show all-videos-completed dialog if applicable
    // if (completedVideos.length == videos.length) {
    //   showDialog(
    //     context: context,
    //     builder: (context) => AlertDialog(
    //       title: const Text('All Videos Completed'),
    //       content: const Text(
    //           'You have completed all the videos for this trimester.'),
    //       actions: [
    //         TextButton(
    //           onPressed: () {
    //             Navigator.of(context).pop();
    //             Navigator.of(context).pop(); // Navigate back
    //           },
    //           child: const Text('OK'),
    //         ),
    //       ],
    //     ),
    //   );
    // }
  }

  @override
  void playVideo(int index) {
    setState(() {
      showVideo = true;
      currentVideoIndex = index;
      _controller = VideoPlayerController.network(videos[index]['source'])
        ..initialize().then((_) {
          setState(() {
            _controller.play();
          });
        });
      _controller.addListener(() {
        if (_controller.value.position == _controller.value.duration) {
          handleVideoEnd();
        }
      });
    });
  }

  void rotateVideo() {
    setState(() {
      rotationAngle += 90; // Rotate the video by 90 degrees each time
      if (rotationAngle == 360) {
        rotationAngle = 0; // Reset rotation if it exceeds 360 degrees
      }
    });
  }

  void seekForward() {
    final currentPosition = _controller.value.position;
    final newPosition = currentPosition + const Duration(seconds: 10);
    _controller.seekTo(newPosition);
  }

  void seekBackward() {
    final currentPosition = _controller.value.position;
    final newPosition = currentPosition - const Duration(seconds: 10);
    _controller.seekTo(newPosition);
  }

  void _showMentalHealthPoll() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          contentPadding: const EdgeInsets.all(16.0),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'How do you feel today?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              StatefulBuilder(
                builder: (context, setState) {
                  return Column(
                    children: [
                      RadioListTile(
                        title: const Text('MORE RELAXED'),
                        value: 'MORE RELAXED',
                        groupValue: selectedOption,
                        onChanged: (value) {
                          setState(() {
                            selectedOption = value.toString();
                          });
                        },
                      ),
                      RadioListTile(
                        title: const Text('HAPPY'),
                        value: 'HAPPY',
                        groupValue: selectedOption,
                        onChanged: (value) {
                          setState(() {
                            selectedOption = value.toString();
                          });
                        },
                      ),
                      RadioListTile(
                        title: const Text('LESS ANXIOUS'),
                        value: 'LESS ANXIOUS',
                        groupValue: selectedOption,
                        onChanged: (value) {
                          setState(() {
                            selectedOption = value.toString();
                          });
                        },
                      ),
                      RadioListTile(
                        title: const Text('NO CHANGE'),
                        value: 'NO CHANGE',
                        groupValue: selectedOption,
                        onChanged: (value) {
                          setState(() {
                            selectedOption = value.toString();
                          });
                        },
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () async {
                if (selectedOption.isNotEmpty) {
                  // Record data and close poll on success

                  await recordMentalHealthData(selectedOption);
                  Navigator.of(context).pop(); // Close the dialog
                } else {
                  // Show a message if no option is selected
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please select an option.')),
                  );
                }
              },
              child: const Text('Submit'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  Widget buildDisclaimerScreen() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            "Disclaimer",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: const Color.fromARGB(235, 228, 8, 8),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: SingleChildScrollView(
              child: Text(
                "The exercises shown in this app are for guidance purposes only and are at the user's discretion.Consult your doctor and avoid these exercises if you experience any of the following symptoms:\n\n"
                "1. Bleeding from the vagina\n"
                "2. High BP\n"
                "3. Decreased baby movements\n"
                "4. Watery discharge from the vagina\n"
                "5. Giddiness\n"
                "6. Palpitation\n"
                "7. Abdominal Pain\n"
                "8. Fainting\n"
                "9. Swelling of the feet\n"
                "10. Fever\n"
                "11. Blurring of vision\n"
                "12. Excess vomiting\n"
                "13. Any discomfort\n"
                "14. Any other complications\n",
                style: TextStyle(
                  fontSize: 16,
                  height: 1.5, // Improves line spacing for readability
                ),
                textAlign: TextAlign.justify,
              ),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                showDisclaimer = false; // Hide disclaimer and show videos
              });
            },
            icon: Icon(Icons.check_circle),
            label: Text("I Understand"),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              textStyle: TextStyle(fontSize: 18),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildVideoList() {
    return ListView.builder(
      itemCount: videos.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: Image.network(videos[index]['thumbnail']),
          title: Text(videos[index]['videoName']),
          onTap: () {
            // Handle video playback
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    bool isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Videos Recommendation',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: showDisclaimer
          ? buildDisclaimerScreen()
          // Toggle between disclaimer and video list
          : showVideo
              ? Center(
                  child: _controller.value.isInitialized
                      ? Column(
                          children: [
                            Expanded(
                              child: FittedBox(
                                fit: BoxFit.cover,
                                child: SizedBox(
                                  width: isLandscape
                                      ? MediaQuery.of(context).size.height
                                      : MediaQuery.of(context).size.width,
                                  height: isLandscape
                                      ? MediaQuery.of(context).size.width
                                      : MediaQuery.of(context).size.height,
                                  child: Transform.rotate(
                                    angle: rotationAngle * 3.14159 / 180,
                                    child: VideoPlayer(_controller),
                                  ),
                                ),
                              ),
                            ),
                            VideoProgressIndicator(_controller,
                                allowScrubbing: true),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                IconButton(
                                  icon: Icon(
                                    _controller.value.isPlaying
                                        ? Icons.pause
                                        : Icons.play_arrow,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      _controller.value.isPlaying
                                          ? _controller.pause()
                                          : _controller.play();
                                    });
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(Icons.stop),
                                  onPressed: () {
                                    _controller.seekTo(Duration.zero);
                                    _controller.pause();
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(Icons.rotate_right),
                                  onPressed: rotateVideo,
                                ),
                                IconButton(
                                  icon: const Icon(Icons.replay_10),
                                  onPressed: seekBackward,
                                ),
                                IconButton(
                                  icon: const Icon(Icons.forward_10),
                                  onPressed: seekForward,
                                ),
                              ],
                            ),
                          ],
                        )
                      : const CircularProgressIndicator(), // Show loading until the video initializes
                )
              : GridView.builder(
                  padding: const EdgeInsets.all(8.0),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 0.8,
                  ),
                  itemCount: videos.length,
                  itemBuilder: (context, index) {
                    var video = videos[index];
                    bool isCompletedToday =
                        completedVideos.contains(video['id']);
                    return Card(
                      child: InkWell(
                        onTap: () => playVideo(index),
                        child: Column(
                          children: [
                            Expanded(
                              child: Image.network(
                                video['thumbnail'],
                                fit: BoxFit.cover,
                                width: double.infinity,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    video['videoName'],
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold),
                                  ),
                                  if (isCompletedToday)
                                    const Text('Completed Today',
                                        style: TextStyle(color: Colors.green)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
