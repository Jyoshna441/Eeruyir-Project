import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:Eeruyir/SelectionScreen.dart';
import 'package:Eeruyir/TermsScreen.dart';
import 'package:Eeruyir/uril.dart';

class HorizontalPreview extends StatefulWidget {
  final String patientId;

  const HorizontalPreview({super.key, required this.patientId});

  @override
  _HorizontalPreviewState createState() => _HorizontalPreviewState();
}

class _HorizontalPreviewState extends State<HorizontalPreview> {
  bool loading = true;
  List<dynamic> data = [];
  List<List<String>> answers = List.generate(4, (_) => []);
  bool showSubmit = true;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final response = await http.get(
        Uri.parse(
            '${Urils.Url}/Eeruyir/select.php?patientId=${widget.patientId}'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          data = jsonData;
          answers = List.generate(4, (_) => []);
          for (int i = 0; i < data.length; i++) {
            int questionId = int.parse(data[i]['questionId'].toString());
            int categoryIndex;

            // Assign questions to the appropriate category
            if (questionId <= 19) {
              categoryIndex = 0; // Present Obstetric History
            } else if (questionId <= 31) {
              categoryIndex = 1; // Medical History
            } else if (questionId <= 38) {
              categoryIndex = 2; // Surgical History
            } else {
              categoryIndex = 3; // Trauma History
            }

            answers[categoryIndex].add(data[i]['answer'] ?? '');
          }
          loading = false;
        });
      } else {
        throw Exception('Failed to fetch data');
      }
    } catch (e) {
      setState(() {
        loading = false;
      });
      showDialog(
        context: context,
        builder: (context) => AlertDialog(content: Text(e.toString())),
      );
    }
  }

  void handleAnswerChange(int categoryIndex, int questionIndex, String value) {
    setState(() {
      if (questionIndex < answers[categoryIndex].length) {
        answers[categoryIndex][questionIndex] = value;
      }
    });
  }

  Future<void> handleSubmit() async {
    final answersObject = <String, String>{};
    bool notEligible = false;

    for (int categoryIndex = 0;
        categoryIndex < answers.length;
        categoryIndex++) {
      for (int questionIndex = 0;
          questionIndex < answers[categoryIndex].length;
          questionIndex++) {
        final questionId = data[questionIndex]['questionId'].toString();
        final answer = answers[categoryIndex][questionIndex];

        answersObject[questionId] = answer;
        if (answer.toLowerCase() == 'yes') {
          notEligible = true;
        }
      }
    }

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/select.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'patientId': widget.patientId,
          'answers': answersObject,
        }),
      );

      final jsonResponse = json.decode(response.body);
      if (response.statusCode == 200) {
        if (notEligible) {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Not Eligible to Create Account'),
              content:
                  const Text('One or more answers indicate ineligibility.'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const SelectionScreen(),
                    ),
                  ),
                  child: const Text('Show Reasons'),
                ),
                TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const SelectionScreen(),
                    ),
                  ),
                  child: const Text('OK'),
                ),
              ],
            ),
          );
        } else {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Eligible'),
              content: const Text('You are eligible to create an account.'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          TermsScreen(), // Replace TermsScreen with your actual screen widget
                    ),
                  ),
                  child: const Text('OK'),
                ),
              ],
            ),
          );
        }
      } else {
        throw Exception(jsonResponse['message'] ?? 'Failed to submit data');
      }
    } catch (e) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(content: Text(e.toString())),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Preview Data',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: PageView.builder(
                    itemCount: 4,
                    itemBuilder: (context, categoryIndex) {
                      final title = [
                        'Present Obstetric History',
                        'Medical History',
                        'Surgical History',
                        'Trauma History',
                      ][categoryIndex];
                      final categoryData = data.sublist(
                        categoryIndex == 0
                            ? 0
                            : (categoryIndex == 1
                                ? 19
                                : (categoryIndex == 2 ? 31 : 38)),
                        categoryIndex == 0
                            ? 19
                            : (categoryIndex == 1
                                ? 31
                                : (categoryIndex == 2 ? 38 : 40)),
                      );

                      return Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF333333),
                              ),
                            ),
                            const SizedBox(height: 16),
                            Expanded(
                              child: ListView.builder(
                                itemCount: categoryData.length,
                                itemBuilder: (context, questionIndex) {
                                  final question =
                                      categoryData[questionIndex]['question'];
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 8.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          question,
                                          style: const TextStyle(
                                            fontSize: 16,
                                            color: Color(0xFF555555),
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        TextFormField(
                                          initialValue: answers[categoryIndex]
                                              [questionIndex],
                                          onChanged: (value) =>
                                              handleAnswerChange(
                                            categoryIndex,
                                            questionIndex,
                                            value,
                                          ),
                                          decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            filled: true,
                                            fillColor: const Color(0xFFF7F7F7),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                if (showSubmit)
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: ElevatedButton(
                      onPressed: handleSubmit,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            vertical: 16.0, horizontal: 32.0),
                        backgroundColor: const Color(0xFF007DFE),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      child: const Text(
                        'Submit',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}
