import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/SurgicalHistory.dart';
import 'package:Eeruyir/uril.dart';

class MedicalHistory1 extends StatefulWidget {
  final String patientId;

  const MedicalHistory1({super.key, required this.patientId});

  @override
  _MedicalHistory1State createState() => _MedicalHistory1State();
}

class _MedicalHistory1State extends State<MedicalHistory1> {
  String psychiatricDisorder = '';
  String historyOfTB = '';
  String autoimmuneDisorder = '';
  String historyOfPolio = '';
  String lowerLimbWeakness = '';
  String additionalMedicalConditions = '';

  Future<void> handleSubmit() async {
    if (psychiatricDisorder.isEmpty ||
        historyOfTB.isEmpty ||
        autoimmuneDisorder.isEmpty ||
        historyOfPolio.isEmpty ||
        lowerLimbWeakness.isEmpty ||
        additionalMedicalConditions.isEmpty) {
      showAlert("Error", "Please answer all the questions.");
      return;
    }

    List<Map<String, dynamic>> responses = [
      {'categoryId': 2, 'questionId': 26, 'answer': psychiatricDisorder},
      {'categoryId': 2, 'questionId': 27, 'answer': historyOfTB},
      {'categoryId': 2, 'questionId': 28, 'answer': autoimmuneDisorder},
      {'categoryId': 2, 'questionId': 29, 'answer': historyOfPolio},
      {'categoryId': 2, 'questionId': 30, 'answer': lowerLimbWeakness},
      {
        'categoryId': 2,
        'questionId': 31,
        'answer': additionalMedicalConditions
      },
    ];

    try {
      final response = await http.post(
        Uri.parse("${Urils.Url}/Eeruyir/Categoriesanswer.php"),
        headers: {'Content-Type': 'application/json'},
        body: json
            .encode({'patientId': widget.patientId, 'responses': responses}),
      );

      final result = json.decode(response.body);

      if (response.statusCode == 200) {
        showAlert('Success',
            'Patient details saved successfully. Patient ID: ${result['patientId']}');
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                SurgicalHistory(patientId: result['patientId']),
          ),
        );
      } else {
        showAlert("Error", result['message'] ?? 'Failed to submit data');
      }
    } catch (error) {
      showAlert("Error", "Failed to submit data");
      print("Error submitting data: $error");
    }
  }

  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK')),
        ],
      ),
    );
  }

  // Building the question widgets
  // Widget buildQuestion(String question, ValueChanged<String?> onChanged) {
  //   return Column(
  //     crossAxisAlignment: CrossAxisAlignment.start,
  //     children: [
  //       Text(question, style: const TextStyle(fontSize: 16)),
  //       Row(
  //         mainAxisAlignment: MainAxisAlignment.start,
  //         children: [
  //           Expanded(
  //             child: RadioListTile<String?>(
  //               title: const Text('Yes'),
  //               value: 'yes',
  //               groupValue: (question == 'Do you have Psychiatric disorder?')
  //                   ? psychiatricDisorder
  //                   : (question == 'Do you have HISTORY OF TB infection?')
  //                       ? historyOfTB
  //                       : (question ==
  //                               'Do you have Any AUTOIMMUNE disorder (Eg: SLE, APLA, Rheumatoid arthritis, etc)?')
  //                           ? autoimmuneDisorder
  //                           : (question == 'Any history of polio attack?')
  //                               ? historyOfPolio
  //                               : (question ==
  //                                       'Do you have any weakness in the lower limb? If yes - do not show videos')
  //                                   ? lowerLimbWeakness
  //                                   : '',
  //               onChanged: onChanged,
  //             ),
  //           ),
  //           Expanded(
  //             child: RadioListTile<String?>(
  //               title: const Text('No'),
  //               value: 'no',
  //               groupValue: (question == 'Do you have Psychiatric disorder?')
  //                   ? psychiatricDisorder
  //                   : (question == 'Do you have HISTORY OF TB infection?')
  //                       ? historyOfTB
  //                       : (question ==
  //                               'Do you have Any AUTOIMMUNE disorder (Eg: SLE, APLA, Rheumatoid arthritis, etc)?')
  //                           ? autoimmuneDisorder
  //                           : (question == 'Any history of polio attack?')
  //                               ? historyOfPolio
  //                               : (question ==
  //                                       'Do you have any weakness in the lower limb? If yes - do not show videos')
  //                                   ? lowerLimbWeakness
  //                                   : '',
  //               onChanged: onChanged,
  //             ),
  //           ),
  //         ],
  //       ),
  //       const SizedBox(height: 10),
  //     ],
  //   );
  // }

  Widget buildQuestion(String question, ValueChanged<String?> onChanged) {
    String? groupValue;
    if (question == 'Do you have Psychiatric disorder?') {
      groupValue = psychiatricDisorder;
    } else if (question == 'Do you have HISTORY OF TB infection?') {
      groupValue = historyOfTB;
    } else if (question ==
        'Do you have Any AUTOIMMUNE disorder (Eg: SLE, APLA, Rheumatoid arthritis, etc)?') {
      groupValue = autoimmuneDisorder;
    } else if (question ==
        'Any history of polio attack? If yes, mention if there is any weakness in lower limb?') {
      groupValue = historyOfPolio;
    } else if (question ==
        'Do you have any weakness in the lower limb? If yes - do not show videos') {
      groupValue = lowerLimbWeakness;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(question, style: const TextStyle(fontSize: 16)),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('Yes'),
                value: 'yes',
                groupValue: groupValue,
                onChanged: onChanged,
              ),
            ),
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('No'),
                value: 'no',
                groupValue: groupValue,
                onChanged: onChanged,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  Widget buildTextBoxQuestion(
      String question, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(question, style: const TextStyle(fontSize: 16)),
        TextField(
          onChanged: onChanged,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Please provide details if any...',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Medical History',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildQuestion(
                    'Do you have Psychiatric disorder?',
                    (value) =>
                        setState(() => psychiatricDisorder = value ?? '')),
                buildQuestion('Do you have HISTORY OF TB infection?',
                    (value) => setState(() => historyOfTB = value ?? '')),
                buildQuestion(
                    'Do you have Any AUTOIMMUNE disorder (Eg: SLE, APLA, Rheumatoid arthritis, etc)?',
                    (value) =>
                        setState(() => autoimmuneDisorder = value ?? '')),
                buildQuestion(
                  'Any history of polio attack? If yes, mention if there is any weakness in lower limb?',
                  (value) => setState(() => historyOfPolio = value ?? ''),
                ),
                buildQuestion(
                    'Do you have any weakness in the lower limb? If yes - do not show videos',
                    (value) => setState(() => lowerLimbWeakness = value ?? '')),
                buildTextBoxQuestion(
                    'Do you have any medical conditions that haven\'t been mentioned before?',
                    (value) => setState(
                        () => additionalMedicalConditions = value ?? '')),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 30),
                    textStyle: const TextStyle(fontSize: 16),
                  ),
                  onPressed: handleSubmit,
                  child: const Text('Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
