import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/PatientLoginScreen.dart';
import 'package:Eeruyir/uril.dart';

class PatientSignup extends StatefulWidget {
  const PatientSignup({super.key});

  @override
  _PatientSignupState createState() => _PatientSignupState();
}

class _PatientSignupState extends State<PatientSignup> {
  String username = '';
  String password = '';
  String confirmPassword = '';
  String phoneNumber = '';
  bool isUsernameFocused = false;
  bool isPasswordFocused = false;
  bool isConfirmPasswordFocused = false;
  bool isPhoneNumberFocused = false;

  Future<void> handleSignUp() async {
    if (username.isEmpty ||
        password.isEmpty ||
        confirmPassword.isEmpty ||
        phoneNumber.isEmpty) {
      showAlert("Error", "Please fill in all fields");
      return;
    }

    if (password != confirmPassword) {
      showAlert("Error", "Password and confirm password do not match");
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/signup.php'),
        headers: {
          "Content-Type": "application/json", // Send content as JSON
        },
        body: jsonEncode({
          'username': username,
          'password': password,
          'phonenumber': phoneNumber,
        }),
      );

      final data = jsonDecode(response.body);

      if (data['message'] == "User registered successfully") {
        showAlert(
          "Welcome",
          "Your account is created. Thank you for showing interest in this app.",
          action: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PatientLoginScreen()),
          ),
        );
      } else {
        showAlert("Error", data['message']);
      }
    } catch (error) {
      showAlert("Error", "An error occurred. Please try again later.");
    }
  }

  void showAlert(String title, String message, {VoidCallback? action}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              if (action != null) action();
            },
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  Widget buildTextInput(String hint, bool obscureText, bool isFocused,
      Function(String) onChanged, Function(bool) setFocus) {
    return Container(
      height: 50,
      margin: const EdgeInsets.only(bottom: 15),
      child: TextField(
        obscureText: obscureText,
        onChanged: onChanged,
        style:
            const TextStyle(color: Colors.black), // Text color inside the field
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white.withOpacity(0.7),
          contentPadding: const EdgeInsets.symmetric(horizontal: 15),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: BorderSide.none,
          ),
          hintText: isFocused ? null : hint,
          hintStyle: TextStyle(
            color:
                isFocused ? Colors.transparent : Colors.black.withOpacity(0.5),
          ),
        ),
        onTap: () => setFocus(true),
        onEditingComplete: () => setFocus(false),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Image.asset(
            'assets/s1.png',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  buildTextInput(
                    "Username",
                    false,
                    isUsernameFocused,
                    (value) => setState(() => username = value),
                    (focus) => setState(() => isUsernameFocused = focus),
                  ),
                  buildTextInput(
                    "Password",
                    true,
                    isPasswordFocused,
                    (value) => setState(() => password = value),
                    (focus) => setState(() => isPasswordFocused = focus),
                  ),
                  buildTextInput(
                    "Confirm Password",
                    true,
                    isConfirmPasswordFocused,
                    (value) => setState(() => confirmPassword = value),
                    (focus) => setState(() => isConfirmPasswordFocused = focus),
                  ),
                  buildTextInput(
                    "Phone Number",
                    false,
                    isPhoneNumberFocused,
                    (value) => setState(() => phoneNumber = value),
                    (focus) => setState(() => isPhoneNumberFocused = focus),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    onPressed: handleSignUp,
                    child: const Text(
                      "Sign Up",
                      style: TextStyle(
                        fontSize: 18,
                        color: Color(0xFF4B0082),
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const PatientLoginScreen()),
                    ),
                    child: const Text(
                      "Already have an account? Login",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
