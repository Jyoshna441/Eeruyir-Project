import 'package:Eeruyir/SelectionScreen.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:ionicons/ionicons.dart';
import 'package:Eeruyir/DocsignScreen.dart';
import 'package:Eeruyir/DoctorDashboard.dart';
import 'uril.dart';

class DoctorLogin extends StatefulWidget {
  const DoctorLogin({super.key});

  @override
  _DoctorLoginState createState() => _DoctorLoginState();
}

class _DoctorLoginState extends State<DoctorLogin> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;

  Future<void> handleLogin(BuildContext context) async {
    final loginApiUrl = '${Urils.Url}/Eeruyir/Doctor.php';
    if (_usernameController.text.isEmpty || _passwordController.text.isEmpty) {
      _showErrorDialog(context, 'Please fill in all fields.');
      return;
    }
    setState(() => _isLoading = true);
    try {
      final response = await http.post(
        Uri.parse(loginApiUrl),
        headers: <String, String>{'Content-Type': 'application/json'},
        body: jsonEncode(<String, String>{
          'username': _usernameController.text,
          'password': _passwordController.text,
        }),
      );

      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        _showSuccessDialog(context);
      } else {
        _showErrorDialog(
            context, 'Invalid username or password. Please try again.');
      }
    } catch (error) {
      _showErrorDialog(context, 'Login failed. Please check your connection.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Success'),
          content: const Text('Login successful!'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close dialog
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          DoctorDashboard(username: _usernameController.text)),
                );
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void handleSignUp(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const DocSignScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final double windowWidth = MediaQuery.of(context).size.width;
    final double windowHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Stack(
        children: [
          // Background Gradient
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.lightBlue.shade200, Colors.blue.shade800],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          // Main content
          SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: windowWidth * 0.05,
                vertical: windowHeight * 0.1,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _buildWelcomeText(windowWidth),
                  const SizedBox(height: 30),
                  _buildTextField(
                      _usernameController, 'Username', Ionicons.person_outline),
                  const SizedBox(height: 20),
                  _buildTextField(_passwordController, 'Password',
                      Ionicons.lock_closed_outline,
                      obscureText: true),
                  const SizedBox(height: 30),
                  _buildButton('Login', Colors.blueGrey,
                      () => handleLogin(context), windowWidth, windowHeight),
                  const SizedBox(height: 20),
                  if (_isLoading)
                    const CircularProgressIndicator(color: Colors.white),
                ],
              ),
            ),
          ),
          // Back arrow
          Positioned(
            top: MediaQuery.of(context).padding.top +
                10, // Adjust for status bar height
            left: 10,
            child: IconButton(
              icon: const Icon(Ionicons.arrow_back, color: Colors.white),
              iconSize: 30,
              onPressed: () {
                // or `onTap: () {` based on your preference
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SelectionScreen(
                        // Optionally, pass any data like patientId if needed
                        // patientId: <your_patient_id>,
                        ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // Welcome text widget
  Widget _buildWelcomeText(double windowWidth) {
    return Text(
      'WELCOME',
      style: TextStyle(
        fontSize: windowWidth * 0.08,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
    );
  }

  // TextField widget
  Widget _buildTextField(
      TextEditingController controller, String labelText, IconData icon,
      {bool obscureText = false}) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white.withOpacity(0.9),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        labelText: labelText,
        prefixIcon: Icon(icon, color: Colors.blueAccent),
      ),
    );
  }

  // Button widget
  Widget _buildButton(String text, Color color, VoidCallback onPressed,
      double windowWidth, double windowHeight) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        minimumSize: Size(windowWidth * 0.6, windowHeight * 0.07),
        backgroundColor: color,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
      child: Text(text, style: const TextStyle(fontSize: 18)),
    );
  }
}
