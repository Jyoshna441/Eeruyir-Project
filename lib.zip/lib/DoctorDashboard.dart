import 'dart:convert';
import 'package:Eeruyir/SelectionScreen.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/BlockScreen.dart';
import 'package:Eeruyir/DefaultList.dart';
import 'package:Eeruyir/DefautList1.dart';
import 'package:Eeruyir/Doctorlogin.dart';
import 'package:Eeruyir/PatientProfile.dart';
import 'package:Eeruyir/DoctorProfile.dart';
import 'package:Eeruyir/outcometab.dart';
import 'package:Eeruyir/Blockpatient.dart';
import 'package:Eeruyir/HIGHRISK.dart';
import 'package:Eeruyir/regularfollow.dart';
import 'package:Eeruyir/irregularfollow.dart';
import 'package:Eeruyir/MentalHealthReport.dart';
import 'package:Eeruyir/uril.dart';

// void main() {
//   runApp(const DoctorDashboard(username: '',));
// }

class DoctorDashboard extends StatefulWidget {
  final String username;

  const DoctorDashboard({super.key, required this.username});

  @override
  _DoctorDashboardState createState() => _DoctorDashboardState();
}

class _DoctorDashboardState extends State<DoctorDashboard>
    with SingleTickerProviderStateMixin {
  bool menuVisible = false;
  List patients = [];
  int followUpCount = 0;
  AnimationController? _controller;
  late Animation<double> opacityAnim;
  late Animation<Offset> translateYAnim;

  @override
  void initState() {
    print('Username: ${widget.username}');
    super.initState();
    print('Username: ${widget.username}');
    fetchPatients();
    fetchFollowUpCount();
    print('Username: ${widget.username}');
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    opacityAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller!, curve: Curves.easeInOut),
    );

    translateYAnim = Tween<Offset>(begin: const Offset(0, -1), end: Offset.zero)
        .animate(
            CurvedAnimation(parent: _controller!, curve: Curves.easeInOut));
  }

  Future<void> fetchPatients() async {
    try {
      final response = await http
          .get(Uri.parse('${Urils.Url}/Eeruyir/getPatients.php'))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(response.body);
      setState(() {
        patients = data;
      });
    } catch (error) {
      print('Error fetching patient data: $error');
    }
  }

  Future<void> fetchFollowUpCount() async {
    try {
      final response =
          await http.get(Uri.parse('${Urils.Url}/Eeruyir/activeusers.php'));
      final data = jsonDecode(response.body);
      setState(() {
        followUpCount = data['followUpCount'] ?? 0;
      });
    } catch (error) {
      print('Error fetching follow-up count: $error');
    }
  }

  Future<String> fetchProfileImage(String patientId) async {
    final url = '${Urils.Url}/Eeruyir/profileimage.php?patient_id=$patientId';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data.containsKey('profile_photo')) {
          return data['profile_photo']; // Return the profile photo URL
        } else {
          throw Exception('Profile photo not found.');
        }
      } else {
        throw Exception('Failed to fetch profile photo.');
      }
    } catch (e) {
      print('Error fetching profile image: $e');
      throw e;
    }
  }

  void toggleMenu() {
    setState(() {
      menuVisible = !menuVisible;
    });
    menuVisible ? _controller?.forward() : _controller?.reverse();
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: menuVisible ? () => toggleMenu() : null,
        child: Stack(
          children: [
            Column(
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.fromLTRB(
                      16, 40, 16, 16), // Increased top padding
                  color: const Color(0xFF007DFE),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.menu,
                                color: Colors.white, size: 30),
                            onPressed: toggleMenu,
                          ),
                          GestureDetector(
                            onTap: () {
                              print('Username: ${widget.username}');
                              // Navigate to DoctorProfile and pass the username
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DoctorDetailsScreen(
                                    username: widget
                                        .username, // Pass the username here
                                  ),
                                ),
                              );
                            },
                            child: const CircleAvatar(
                              radius: 20,
                              backgroundImage: AssetImage('assets/dp2.png'),
                            ),
                          ),
                        ],
                      ),

                      // const SizedBox(height: 16), // Add spacing between rows
                      // Search Bar
                      // Row(
                      //   children: [
                      //     Expanded(
                      //       child: TextField(
                      //         decoration: InputDecoration(
                      //           hintText: 'Search',
                      //           fillColor: Colors.white,
                      //           filled: true,
                      //           border: OutlineInputBorder(
                      //             borderRadius: BorderRadius.circular(50),
                      //             borderSide: BorderSide.none,
                      //           ),
                      //           prefixIcon: const Icon(Icons.search),
                      //         ),
                      //       ),
                      //     ),
                      //     const SizedBox(width: 10),
                      //     const CircleAvatar(
                      //       backgroundColor: Colors.white,
                      //       child:
                      //           Icon(Icons.notifications, color: Colors.black),
                      //     ),
                      //   ],
                      // ),
                    ],
                  ),
                ),
                // ScrollView Content
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      // Patient Profiles
                      ...patients.map((patient) {
                        return Card(
                          child: ListTile(
                            leading: FutureBuilder(
                              future: fetchProfileImage(patient['patient_id']),
                              builder: (context, snapshot) {
                                if (snapshot.connectionState ==
                                    ConnectionState.waiting) {
                                  return CircularProgressIndicator(); // Show a loader while fetching the image
                                } else if (snapshot.hasError ||
                                    !snapshot.hasData) {
                                  return ClipOval(
                                    child: Image.asset(
                                      'assets/images/placeholder.png', // Fallback image
                                      width: 50, // Set a fixed width
                                      height: 50, // Set a fixed height
                                      fit: BoxFit
                                          .cover, // Ensure the image covers the entire area
                                    ),
                                  );
                                } else {
                                  return ClipOval(
                                    child: FadeInImage.assetNetwork(
                                      placeholder:
                                          'assets/images/placeholder.png', // Local asset as placeholder
                                      image: snapshot.data
                                          as String, // The URL of the fetched profile image
                                      width: 50, // Set a fixed width
                                      height: 50, // Set a fixed height
                                      fit: BoxFit
                                          .cover, // Ensure the image covers the circular area
                                      imageErrorBuilder:
                                          (context, error, stackTrace) {
                                        return Image.asset(
                                          'assets/images/placeholder.png', // Fallback image
                                          width:
                                              50, // Same dimensions as the image
                                          height: 50,
                                          fit: BoxFit.cover,
                                        );
                                      },
                                    ),
                                  );
                                }
                              },
                            ),
                            title: Text('Patient ID: ${patient['patient_id']}'),
                            subtitle: Text(
                              'Last updated: ${DateTime.parse(patient['created_at']).toLocal().toString()}',
                            ),
                            onTap: () {
                              // Navigate to PatientProfile and pass the patientId
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => PatientProfile(
                                    patientId: patient['patient_id'],
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }),
                      // Stats
                      Row(
                        children: [
                          Expanded(
                            child: StatBox(
                              label: 'Total Patients',
                              value: patients.length.toString(),
                            ),
                          ),
                          Expanded(
                            child: StatBox(
                              label: 'Active Users',
                              value: followUpCount.toString(),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            // Sliding Menu
            if (menuVisible)
              Positioned.fill(
                child: GestureDetector(
                  onTap: toggleMenu,
                  child: Container(
                    color: Colors.black54,
                    child: SlideTransition(
                      position: translateYAnim,
                      child: Align(
                        alignment: Alignment
                            .centerLeft, // Aligns the container to the left
                        child: Container(
                          width: MediaQuery.of(context).size.width *
                              0.8, // 80% of the screen width
                          color: Colors.white,
                          child: Column(
                            children: [
                              // Adding a Container with blue background and increased height for 'Eeruyir'
                              Container(
                                color: Colors.blue, // Background color blue
                                height: 100.0, // Increased height
                                child: const Center(
                                  child: Text(
                                    'Eeruyir',
                                    style: TextStyle(
                                      fontSize: 24,
                                      color: Colors
                                          .white, // Text color white for contrast
                                    ),
                                  ),
                                ),
                              ),
                              // Increased Divider height and thickness
                              const Divider(
                                height: 20, // Adds spacing around the divider
                                thickness: 2, // Thickness of the divider
                              ),
                              MenuItem(
                                title: 'Outcome of Delivery',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const OutcomeTab(), // Directly calling the class
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Block Patient Id',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BlockPatientScreen(
                                      navigateToProfile: (String) {},
                                    ), // Directly calling the class
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'High Risk Patient',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const Highrisk(), // Directly calling the class
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Videos Blocked List',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        BlockScreen(), // Directly calling the class
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Regular Follow up Patient',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const RegularFollowUpPatientsScreen(), // Directly calling the class
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Inactive Follow up Patient',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const IrregularFollow(), // Directly calling the class
                                  ),
                                ),
                              ),
                              // MenuItem(
                              //   title: 'Pending Data Submission',
                              //   onTap: () => Navigator.push(
                              //     context,
                              //     MaterialPageRoute(
                              //       builder: (context) =>
                              //            DefaultList(), // Directly calling the class
                              //     ),
                              //   ),
                              // ),
                              MenuItem(
                                title: 'Alert Patients',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        DefaultList(), // Directly calling the class
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Mental Health Assessment',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const MentalHealthReport(), // Directly calling the class
                                  ),
                                ),
                              ),
                              // Increased Divider height and thickness
                              const Divider(
                                height: 20, // Adds spacing around the divider
                                thickness: 2, // Thickness of the divider
                              ),
                              MenuItem(
                                title: 'Logout',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const SelectionScreen(), // Directly calling the class
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class StatBox extends StatelessWidget {
  final String label;
  final String value;

  const StatBox({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(label, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text(value,
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class MenuItem extends StatelessWidget {
  final String title;
  final Function onTap;

  const MenuItem({super.key, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(title),
      onTap: () => onTap(),
    );
  }
}
