import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:flutter/material.dart';
import 'package:Eeruyir/TraumaHistory.dart';

import 'uril.dart';

class SurgicalHistory extends StatefulWidget {
  final String patientId;

  const SurgicalHistory({super.key, required this.patientId});

  @override
  _SurgicalHistoryState createState() => _SurgicalHistoryState();
}

class _SurgicalHistoryState extends State<SurgicalHistory> {
  String lungOrHeartSurgery = '';
  String abdominalSurgeries = '';
  String pelvicSurgeries = '';
  String spineSurgeries = '';
  String kneeOrLegSurgeries = '';
  String cervixStitch = '';
  String medicalConditionsNotMentioned = '';

  Future<void> handleSubmit() async {
    if (lungOrHeartSurgery.isEmpty ||
        abdominalSurgeries.isEmpty ||
        pelvicSurgeries.isEmpty ||
        spineSurgeries.isEmpty ||
        kneeOrLegSurgeries.isEmpty ||
        cervixStitch.isEmpty ||
        medicalConditionsNotMentioned.isEmpty) {
      showAlert("Error", "Please answer all the questions.");
      return;
    }

    List<Map<String, dynamic>> responses = [
      {'categoryId': 3, 'questionId': 32, 'answer': lungOrHeartSurgery},
      {'categoryId': 3, 'questionId': 33, 'answer': abdominalSurgeries},
      {'categoryId': 3, 'questionId': 34, 'answer': pelvicSurgeries},
      {'categoryId': 3, 'questionId': 35, 'answer': spineSurgeries},
      {'categoryId': 3, 'questionId': 36, 'answer': kneeOrLegSurgeries},
      {'categoryId': 3, 'questionId': 37, 'answer': cervixStitch},
      {
        'categoryId': 3,
        'questionId': 38,
        'answer': medicalConditionsNotMentioned
      },
    ];

    try {
      final response = await http.post(
        Uri.parse("${Urils.Url}/Eeruyir/Categoriesanswer.php"),
        headers: {'Content-Type': 'application/json'},
        body: json
            .encode({'patientId': widget.patientId, 'responses': responses}),
      );

      final result = json.decode(response.body);

      if (response.statusCode == 200) {
        showAlert('Success',
            'Patient details saved successfully. Patient ID: ${result['patientId']}');
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => TraumaHistory(patientId: result['patientId']),
          ),
        );
      } else {
        showAlert("Error", result['message'] ?? 'Failed to submit data');
      }
    } catch (error) {
      showAlert("Error", "Failed to submit data");
      print("Error submitting data: $error");
    }
  }

  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK')),
        ],
      ),
    );
  }

  // Building the question widgets
  Widget buildQuestion(String question, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(question, style: const TextStyle(fontSize: 16)),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('Yes'),
                value: 'yes',
                groupValue: (question ==
                        'Any surgery done in the lungs or heart?')
                    ? lungOrHeartSurgery
                    : (question == 'Any abdominal surgeries done in the past?')
                        ? abdominalSurgeries
                        : (question == 'Any pelvic surgeries done in the past?')
                            ? pelvicSurgeries
                            : (question ==
                                    'Any history of spine surgeries done in the past?')
                                ? spineSurgeries
                                : (question ==
                                        'Any history of any surgeries in the knee or leg (which may cause difficulty during delivery)?')
                                    ? kneeOrLegSurgeries
                                    : (question ==
                                            'Have they put a stitch in the cervix?')
                                        ? cervixStitch
                                        : '',
                onChanged: onChanged,
              ),
            ),
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('No'),
                value: 'no',
                groupValue: (question ==
                        'Any surgery done in the lungs or heart?')
                    ? lungOrHeartSurgery
                    : (question == 'Any abdominal surgeries done in the past?')
                        ? abdominalSurgeries
                        : (question == 'Any pelvic surgeries done in the past?')
                            ? pelvicSurgeries
                            : (question ==
                                    'Any history of spine surgeries done in the past?')
                                ? spineSurgeries
                                : (question ==
                                        'Any history of any surgeries in the knee or leg (which may cause difficulty during delivery)?')
                                    ? kneeOrLegSurgeries
                                    : (question ==
                                            'Have they put a stitch in the cervix?')
                                        ? cervixStitch
                                        : '',
                onChanged: onChanged,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Surgical History',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildQuestion(
                    'Any surgery done in the lungs or heart?',
                    (value) =>
                        setState(() => lungOrHeartSurgery = value ?? '')),
                buildQuestion(
                    'Any abdominal surgeries done in the past?',
                    (value) =>
                        setState(() => abdominalSurgeries = value ?? '')),
                buildQuestion('Any pelvic surgeries done in the past?',
                    (value) => setState(() => pelvicSurgeries = value ?? '')),
                buildQuestion(
                    'Any history of spine surgeries done in the past?',
                    (value) => setState(() => spineSurgeries = value ?? '')),
                buildQuestion(
                    'Any history of any surgeries in the knee or leg (which may cause difficulty during delivery)?',
                    (value) =>
                        setState(() => kneeOrLegSurgeries = value ?? '')),
                buildQuestion('Have they put a stitch in the cervix?',
                    (value) => setState(() => cervixStitch = value ?? '')),

                // Medical conditions text box
                const SizedBox(height: 20),
                const Text(
                  'Do you have any medical conditions that haven\'t been mentioned before?',
                  style: TextStyle(fontSize: 16),
                ),
                TextField(
                  onChanged: (value) =>
                      setState(() => medicalConditionsNotMentioned = value),
                  decoration: const InputDecoration(
                    hintText: 'Enter medical conditions here...',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 20),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 30),
                    textStyle: const TextStyle(fontSize: 16),
                  ),
                  onPressed: handleSubmit,
                  child: const Text('Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
