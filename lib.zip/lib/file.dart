const String ip = "180.235.121.245";
const String baseUrl = 'http://$ip/php';

const Map<String, String> file = {
  'ip': ip,
  'baseUrl': baseUrl,
  'doclog': '$baseUrl/Doctor.php',
  'docsign': '$baseUrl/doctorprofile.php',
  'login': '$baseUrl/userlogin.php',
  'signup': '$baseUrl/patient.php',
  'answerquestions': '$baseUrl/answerquestions1.php',
  'age21to34': '$baseUrl/age21bw35.php',
  'search': '$baseUrl/doctorsearch.php',
  'time': '$baseUrl/time.php',
};

String getCategoryUrl(String category) {
  return '$baseUrl/age21.php?category=$category';
}

String getPatientDetailsUrl(String username) {
  return '$baseUrl/patientdetails.php?username=$username';
}

String attend(String username) {
  return '$baseUrl/docques.php?username=$username';
}
