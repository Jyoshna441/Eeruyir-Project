import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:Eeruyir/HorizontalPreview.dart';
// You may need to add a gradient package

import 'uril.dart';

class TraumaHistory extends StatefulWidget {
  final String patientId;

  const TraumaHistory({super.key, required this.patientId});

  @override
  _TraumaHistoryState createState() => _TraumaHistoryState();
}

class _TraumaHistoryState extends State<TraumaHistory> {
  String pelvicTrauma = '';
  String medicalConditionsNotMentioned = '';

  Future<void> handleSubmit() async {
    if (pelvicTrauma.isEmpty || medicalConditionsNotMentioned.isEmpty) {
      showAlert("Error", "Please answer all the questions.");
      return;
    }

    List<Map<String, dynamic>> responses = [
      {'categoryId': 4, 'questionId': 39, 'answer': pelvicTrauma},
      {
        'categoryId': 4,
        'questionId': 40,
        'answer': medicalConditionsNotMentioned
      },
    ];

    try {
      final response = await http.post(
        Uri.parse("${Urils.Url}/Eeruyir/Categoriesanswer.php"),
        headers: {'Content-Type': 'application/json'},
        body: json
            .encode({'patientId': widget.patientId, 'responses': responses}),
      );

      final result = json.decode(response.body);

      if (response.statusCode == 200) {
        showAlert('Success',
            'Patient details saved successfully. Patient ID: ${result['patientId']}');
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                HorizontalPreview(patientId: result['patientId']),
          ),
        );
      } else {
        showAlert("Error", result['message'] ?? 'Failed to submit data');
      }
    } catch (error) {
      showAlert("Error", "Failed to submit data");
      print("Error submitting data: $error");
    }
  }

  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK')),
        ],
      ),
    );
  }

  // Building the question widgets
  Widget buildQuestion(String question, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(question, style: const TextStyle(fontSize: 16)),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('Yes'),
                value: 'yes',
                groupValue: (question ==
                        'Any trauma to the pelvic region, abdomen, leg in this pregnancy?')
                    ? pelvicTrauma
                    : '',
                onChanged: onChanged,
              ),
            ),
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('No'),
                value: 'no',
                groupValue: (question ==
                        'Any trauma to the pelvic region, abdomen, leg in this pregnancy?')
                    ? pelvicTrauma
                    : '',
                onChanged: onChanged,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Trauma History',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Pelvic trauma question
                buildQuestion(
                    'Any trauma to the pelvic region, abdomen, leg in this pregnancy?',
                    (value) => setState(() => pelvicTrauma = value ?? '')),

                // Medical conditions text box
                const SizedBox(height: 20),
                const Text(
                  'Do you have any medical conditions that haven\'t been mentioned before?',
                  style: TextStyle(fontSize: 16),
                ),
                TextField(
                  onChanged: (value) =>
                      setState(() => medicalConditionsNotMentioned = value),
                  decoration: const InputDecoration(
                    hintText: 'Enter medical conditions here...',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 20),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 30),
                    textStyle: const TextStyle(fontSize: 16),
                  ),
                  onPressed: handleSubmit,
                  child: const Text('Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
