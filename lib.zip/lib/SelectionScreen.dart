import 'dart:async';
import 'package:flutter/material.dart';
import 'package:Eeruyir/Doctorlogin.dart';
import 'package:Eeruyir/PatientLoginScreen.dart';

class SelectionScreen extends StatefulWidget {
  const SelectionScreen({super.key});

  @override
  _SelectionScreenState createState() => _SelectionScreenState();
}

class _SelectionScreenState extends State<SelectionScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _rotationAnimation;

  @override
  void initState() {
    super.initState();

    // Animation Controller for continuous rotation
    _controller = AnimationController(
      duration: const Duration(seconds: 3), // Duration for each full rotation
      vsync: this,
    )..repeat(); // Continues repeating the animation

    // Rotation animation from 0 to 360 degrees
    _rotationAnimation =
        Tween<double>(begin: 0, end: 2 * 3.141592653589793).animate(
      CurvedAnimation(parent: _controller, curve: Curves.linear),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void handleDoctorLogin(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const DoctorLogin()),
    );
  }

  void handlePatientLogin(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const PatientLoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Expanded(
            flex: 1,
            child: Center(
              child: AnimatedBuilder(
                animation: _rotationAnimation,
                child: Image.asset(
                  'assets/dp1.png',
                  width: MediaQuery.of(context).size.width * 0.50,
                  height: MediaQuery.of(context).size.width * 0.50,
                ),
                builder: (context, child) {
                  return Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..rotateY(
                          _rotationAnimation.value), // Continuous rotation
                    child: child,
                  );
                },
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: MediaQuery.of(context).size.width * 0.05),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildLoginButton(context, ' Doctor Login ', 'assets/dp2.png',
                      handleDoctorLogin),
                  SizedBox(
                      height: MediaQuery.of(context).size.height *
                          0.03), // Added space between buttons
                  _buildLoginButton(context, ' Patient Login ',
                      'assets/dp4.png', handlePatientLogin),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoginButton(BuildContext context, String title, String imagePath,
      void Function(BuildContext) onPressed) {
    double avatarSize = MediaQuery.of(context).size.width *
        0.12; // Decreased size for smaller avatars
    double buttonWidth = MediaQuery.of(context).size.width * 0.85;

    return Container(
      width: buttonWidth,
      height: MediaQuery.of(context).size.height * 0.18,
      margin: EdgeInsets.symmetric(
          vertical: MediaQuery.of(context).size.height * 0.02),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(30), // Rounded corners for a modern look
        border: Border.all(color: Colors.grey.shade300, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            offset: const Offset(0, 8),
            blurRadius: 10, // Softer shadow for elegance
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: avatarSize, // Reduced size
            backgroundImage: AssetImage(imagePath),
            backgroundColor:
                Colors.white, // Adds a clean background for the image
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                    color: Colors.white,
                    width: 4), // White border around the image
              ),
            ),
          ),
          SizedBox(width: MediaQuery.of(context).size.width * 0.05),
          TextButton(
            onPressed: () => onPressed(context),
            style: TextButton.styleFrom(
              padding: EdgeInsets.symmetric(
                  vertical: MediaQuery.of(context).size.height * 0.02),
              backgroundColor:
                  const Color(0xFF87CEFA), // Lighter, modern button color
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(30), // Rounded button edges for style
              ),
              side: BorderSide(
                  color: const Color.fromARGB(255, 238, 238, 240), width: 2),
            ),
            child: Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: MediaQuery.of(context).size.width *
                    0.05, // Adjusted text size for readability
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
