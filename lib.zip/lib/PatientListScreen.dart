import 'package:flutter/material.dart';
import 'package:http/http.dart' as http; // Import the http package
import 'dart:convert';

import 'uril.dart'; // Import for JSON decoding

class PatientsListScreen extends StatefulWidget {
  const PatientsListScreen({super.key});

  @override
  _PatientsListScreenState createState() => _PatientsListScreenState();
}

class _PatientsListScreenState extends State<PatientsListScreen> {
  List<dynamic> patients = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchPatients();
  }

  Future<void> fetchPatients() async {
    try {
      final response = await http.get(
          Uri.parse('${Urils.Url}/Eeruyir/Listscreen.php')); // Use http.get
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body); // Decode the response body
        setState(() {
          patients = data; // Update the patients list
          loading = false; // Set loading to false
        });
      } else {
        throw Exception('Failed to load patients');
      }
    } catch (error) {
      print('Error fetching patient IDs: $error');
      setState(() {
        loading = false; // Set loading to false on error
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Patient IDs'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text(
              'Patient IDs',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            Expanded(
              child: ListView.builder(
                itemCount: patients.length,
                itemBuilder: (context, index) {
                  return Container(
                    padding: const EdgeInsets.all(16.0),
                    margin: const EdgeInsets.only(bottom: 8.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 1,
                          blurRadius: 5,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Text(
                      patients[index]['patient_id'].toString(),
                      style:
                          const TextStyle(fontSize: 18, color: Colors.black87),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
