import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:Eeruyir/uril.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';

class AlertScreen extends StatefulWidget {
  final String patientId;
  final int months;

  const AlertScreen({super.key, required this.patientId, required this.months});

  @override
  _AlertScreenState createState() => _AlertScreenState();
}

class _AlertScreenState extends State<AlertScreen> {
  bool isLoading = false;
  Map<String, dynamic>? alertData;
  String? imagePath;

  @override
  void initState() {
    super.initState();
    fetchAlert();
  }

  Future<void> fetchAlert() async {
    setState(() {
      isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/get_alert.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'patient_id': widget.patientId,
          'month': widget.months,
        }),
      );

      final jsonResponse = jsonDecode(response.body);
      print('API Response: $jsonResponse');

      if (jsonResponse['error'] != null) {
        showErrorAlert(jsonResponse['error']);
      } else if (jsonResponse['message'] != 'Alert acknowledged.' &&
          jsonResponse['message'] != 'No alert found for the provided month.') {
        alertData = jsonResponse;

        bool canShowAlert = await shouldShowAlert();
        if (canShowAlert) {
          showAlertDialog(jsonResponse);
        }
      }
    } catch (error) {
      showErrorAlert('Failed to fetch alerts. Please try again.');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> handleDoneTests(String alertId) async {
    final picker = ImagePicker();
    final permissionGranted = await picker.requestPermission();

    if (!permissionGranted) {
      showErrorAlert('You need to grant permission to access the library');
      return;
    }

    final pickedFile =
        await picker.pickImage(source: ImageSource.camera, imageQuality: 100);
    if (pickedFile != null) {
      setState(() {
        imagePath = pickedFile.path;
      });

      await uploadSelectedImage(pickedFile.path, widget.patientId, alertId);
    } else {
      print('Image picking was canceled');
    }
  }

  Future<void> uploadSelectedImage(
      String imageUri, String patientId, String alertId) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('${Urils.Url}/Eeruyir/scan.php'),
    );

    request.fields['patient_id'] = patientId;
    request.fields['alert_id'] = alertId;
    request.fields['months'] = widget.months.toString();
    request.files.add(await http.MultipartFile.fromPath('scanImage', imageUri));

    try {
      final response = await request.send();
      final responseData = await http.Response.fromStream(response);

      final result = jsonDecode(responseData.body);
      if (response.statusCode == 200) {
        showSuccessAlert(result['message']);
      } else {
        showErrorAlert(result['message']);
      }
    } catch (error) {
      showErrorAlert('Failed to upload image. Please try again.');
    }
  }

  Future<void> handleDontRemind() async {
    showAlertDialog(
      {
        'title': 'Reminder',
        'message':
            'Please do the testings and consult the doctor as soon as possible.',
      },
      onConfirm: () async {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt(
            'reminderTimestamp', DateTime.now().millisecondsSinceEpoch);
      },
    );
  }

  Future<bool> shouldShowAlert() async {
    final prefs = await SharedPreferences.getInstance();
    final lastReminder = prefs.getInt('reminderTimestamp');

    if (lastReminder != null) {
      final now = DateTime.now().millisecondsSinceEpoch;
      if (now - lastReminder < 24 * 60 * 60 * 1000) {
        return false;
      }
    }
    return true;
  }

  void showAlertDialog(Map<String, dynamic> data, {VoidCallback? onConfirm}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('New Alert!'),
        content: Text(
          'Message: ${data['alert_message']}\n'
          'Tests Required: ${data['tests_required']}\n'
          'Scan Required: ${data['scan_required']}',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              handleDoneTests(data['alert_id'].toString());
            },
            child: const Text('Yes'),
          ),
          TextButton(
            onPressed: () async {
              await handleDontRemind();
              Navigator.pop(context);
            },
            child: const Text('No'),
          ),
        ],
      ),
    );
  }

  void showSuccessAlert(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Success'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void showErrorAlert(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alert Screen'),
      ),
      body: Center(
        child: isLoading
            ? const CircularProgressIndicator()
            : ElevatedButton(
                onPressed: fetchAlert,
                child: const Text('Fetch Alert'),
              ),
      ),
    );
  }
}

extension ImagePickerExtension on ImagePicker {
  Future<bool> requestPermission() async {
    // Check the current status of the permission
    var status = await Permission.photos.status;

    if (status.isDenied) {
      // Request permission if it's denied
      status = await Permission.photos.request();
    }

    return status.isGranted; // Return true if permission is granted
  }
}
