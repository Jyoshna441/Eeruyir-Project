import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:Eeruyir/uril.dart';

class DefaultList1 extends StatefulWidget {
  const DefaultList1({super.key});

  @override
  _DefaultList1State createState() => _DefaultList1State();
}

class _DefaultList1State extends State<DefaultList1> {
  List defaulters = [];
  bool loading = true;
  String alertMessage = '';
  int? selectedPatientId;

  @override
  void initState() {
    super.initState();
    fetchDefaulters();
  }

  // Function to fetch defaulters from the backend
  Future<void> fetchDefaulters() async {
    try {
      final response = await http
          .get(Uri.parse('${Urils.Url}/Eeruyir/check_defaulters.php'));
      final data = json.decode(response.body);
      setState(() {
        defaulters = data;
        loading = false;
      });
    } catch (error) {
      print('Error fetching defaulters: $error');
      setState(() {
        loading = false;
      });
    }
  }

  // Function to send alert to the selected patient
  Future<void> sendAlert() async {
    if (selectedPatientId == null || alertMessage.isEmpty) {
      _showErrorAlert('Please select a patient and enter an alert message.');
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/send_alert.php'),
        headers: {'Content-Type': 'application/json'},
        body: json
            .encode({'patient_id': selectedPatientId, 'message': alertMessage}),
      );

      final result = json.decode(response.body);
      if (result['success']) {
        _showSuccessAlert('Alert sent to patient ID: $selectedPatientId');
        setState(() {
          alertMessage = ''; // Clear the input after sending
        });
      } else {
        _showErrorAlert('Failed to send alert.');
      }
    } catch (error) {
      print('Error sending alert: $error');
      _showErrorAlert('An error occurred while sending the alert.');
    }
  }

  void _showErrorAlert(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            child: const Text('OK'),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }

  void _showSuccessAlert(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Success'),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            child: const Text('OK'),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }

  // Render a single item (patient) in the list
  Widget renderItem(dynamic item) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedPatientId = item['patient_id'];
        });
      },
      child: Container(
        decoration: BoxDecoration(
          color: selectedPatientId == item['patient_id']
              ? Colors.lightBlueAccent
              : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey),
        ),
        padding: const EdgeInsets.all(15),
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          children: [
            Text('Patient ID: ${item['patient_id']}'),
            if (selectedPatientId == item['patient_id'])
              const Text('Selected',
                  style: TextStyle(
                      color: Colors.green, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Pending Data Submissions',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: defaulters.length,
                itemBuilder: (context, index) {
                  return renderItem(defaulters[index]);
                },
              ),
            ),
            Text(selectedPatientId != null
                ? 'Selected Patient ID: $selectedPatientId'
                : 'No patient selected'),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'Type alert message...',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    alertMessage = value;
                  });
                },
              ),
            ),
            ElevatedButton(
              onPressed: sendAlert,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue, // Button background color
                padding:
                    const EdgeInsets.symmetric(vertical: 18), // Button padding
                shape: RoundedRectangleBorder(
                  // Border radius for rounded corners
                  borderRadius: BorderRadius.circular(12),
                ),
                textStyle: const TextStyle(
                  // Font style for the text
                  fontSize: 16, // Font size of the text
                  fontWeight: FontWeight.bold, // Font weight of the text
                  color: Colors.white, // Text color
                ),
              ),
              child: const Text('Send Alert'),
            )
          ],
        ),
      ),
    );
  }
}
