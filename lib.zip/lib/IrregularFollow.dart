import 'package:flutter/material.dart';
import 'dart:convert'; // For json decoding
import 'package:http/http.dart' as http;
import 'package:Eeruyir/PatientProfile.dart';
import 'package:Eeruyir/uril.dart';

class IrregularFollow extends StatefulWidget {
  const IrregularFollow({super.key});

  @override
  _IrregularFollowState createState() => _IrregularFollowState();
}

class _IrregularFollowState extends State<IrregularFollow> {
  List<dynamic> data = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    final url =
        Uri.parse('${Urils.Url}/Eeruyir/fetch_notregular_follow_up.php');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['patients'] != null && result['patients'].isEmpty) {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('No Patients'),
              content: const Text('No irregular follow-up patients found.'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('OK'),
                ),
              ],
            ),
          );
        }
        setState(() {
          data = result['patients'] ?? [];
        });
      } else {
        throw Exception('Failed to load data');
      }
    } catch (error) {
      print('Error fetching data: $error');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void handleViewProfile(String patientId) {
    Navigator.pushNamed(context, '/patientProfile',
        arguments:
            patientId); // Navigate to Patient Profile screen with patientId
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Irregular Followup Patient',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                final item = data[index];
                return GestureDetector(
                  onTap: () => handleViewProfile(item['patient_id']),
                  child: Card(
                    margin:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 4,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            onTap: () {
                              // Navigate to the PatientProfile screen and pass the patient ID
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => PatientProfile(
                                      patientId: item['patient_id']),
                                ),
                              );
                            },
                            child: Text(
                              'Patient ID: ${item['patient_id']}',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w500,
                                color: Color(0xFF0072FF),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          // Text(
                          //   '${item['firstName']} ${item['lastName']}',
                          //   style: const TextStyle(
                          //     fontSize: 16,
                          //     color: Color(0xFF555555),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
