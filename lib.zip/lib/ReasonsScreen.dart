import 'package:flutter/material.dart';

class ReasonsScreen extends StatelessWidget {
  final List<String> reasons;

  const ReasonsScreen({super.key, required this.reasons});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Reasons for Ineligibility'),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: width * 0.05),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Reasons for Ineligibility',
              style: TextStyle(
                fontSize: width * 0.05,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: height * 0.02),
            Expanded(
              child: ListView.builder(
                itemCount: reasons.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(vertical: height * 0.01),
                    child: Text(
                      reasons[index],
                      style: TextStyle(fontSize: width * 0.04),
                      textAlign: TextAlign.center,
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: height * 0.05),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, 'SelectionScreen');
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(
                    vertical: height * 0.02, horizontal: width * 0.2), backgroundColor: Colors.blue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(width * 0.02),
                ), // Button color
              ),
              child: Text(
                'OK',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: width * 0.04,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
