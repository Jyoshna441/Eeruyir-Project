import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';

class Header extends StatelessWidget {
  final String title;
  final BuildContext navigation;

  const Header({super.key, required this.title, required this.navigation});

  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;
    final double height = MediaQuery.of(context).size.height;

    return Container(
      width: double.infinity,
      height: height * 0.12,
      padding: EdgeInsets.symmetric(horizontal: width * 0.02),
      decoration: const BoxDecoration(
        color: Color(0xFF0072FF),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: Icon(Ionicons.md_arrow_back,
                size: width * 0.1, color: Colors.white),
            onPressed: () {
              Navigator.of(context).pop(); // Navigates back
            },
          ),
          SizedBox(width: width * 0.02),
          Text(
            title,
            style: TextStyle(
              fontSize: width * 0.08,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
