import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/PatientProfile.dart';
import 'dart:convert';

import 'package:Eeruyir/uril.dart';

class RegularFollowUpPatientsScreen extends StatefulWidget {
  const RegularFollowUpPatientsScreen({super.key});

  @override
  _RegularFollowUpPatientsScreenState createState() =>
      _RegularFollowUpPatientsScreenState();
}

class _RegularFollowUpPatientsScreenState
    extends State<RegularFollowUpPatientsScreen> {
  List<dynamic> data = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final response = await http
          .get(Uri.parse('${Urils.Url}/Eeruyir/fetch_regular_follow_up.php'));
      if (response.statusCode == 200) {
        final result = json.decode(response.body);

        setState(() {
          data = result['patients'] ?? [];
        });

        // Check if patients list is empty and show alert
        if (data.isEmpty) {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text('No Patients Found'),
                content: const Text('No regular follow-up patients.'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop(); // Close the dialog
                      Navigator.of(context)
                          .pop(); // Go back to the previous screen
                    },
                    child: const Text('OK'),
                  ),
                ],
              );
            },
          );
        }
      } else {
        throw Exception('Failed to load data');
      }
    } catch (error) {
      print('Error fetching data: $error');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void handleViewProfile(int patientId) {
    Navigator.pushNamed(context, '/patientProfile',
        arguments:
            patientId); // Navigate to Patient Profile screen with patientId
  }

  Widget renderPatientItem(dynamic item) {
    return GestureDetector(
      onTap: () => handleViewProfile(item['patient_id']),
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 4,
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  // Navigate to the PatientProfile screen and pass the patient ID
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          PatientProfile(patientId: item['patient_id']),
                    ),
                  );
                },
                child: Text(
                  'Patient ID: ${item['patient_id']}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF0072FF),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              // Text(
              //   '${item['firstName']} ${item['lastName']}',
              //   style: const TextStyle(
              //     fontSize: 16,
              //     color: Color(0xFF555555),
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Regular Followup Patients',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: data.length,
                itemBuilder: (context, index) {
                  return renderPatientItem(data[index]);
                },
              ),
      ),
    );
  }
}
