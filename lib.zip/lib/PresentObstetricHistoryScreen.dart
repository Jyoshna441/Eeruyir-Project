import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:Eeruyir/ObstetricScreen_1.dart';
import 'uril.dart';

class PresentObstetricHistoryScreen extends StatefulWidget {
  final String patientId;

  const PresentObstetricHistoryScreen({super.key, required this.patientId});

  @override
  _PresentObstetricHistoryScreenState createState() =>
      _PresentObstetricHistoryScreenState();
}

class _PresentObstetricHistoryScreenState
    extends State<PresentObstetricHistoryScreen> {
  // Add variables for new questions
  String cervicalIncompetence = '';
  String heartDisease = '';
  String multiplePregnancy = '';
  String diabetesComplication = '';
  String hypertensionComplication = '';
  String hadCSection = '';

  Future<void> handleSubmit() async {
    if (cervicalIncompetence.isEmpty ||
        heartDisease.isEmpty ||
        multiplePregnancy.isEmpty ||
        diabetesComplication.isEmpty ||
        hypertensionComplication.isEmpty ||
        hadCSection.isEmpty) {
      showAlert("Error", "Please answer all the questions.");
      return;
    }

    List<Map<String, dynamic>> responses = [
      {'categoryId': 1, 'questionId': 1, 'answer': cervicalIncompetence},
      {'categoryId': 1, 'questionId': 2, 'answer': heartDisease},
      {'categoryId': 1, 'questionId': 3, 'answer': multiplePregnancy},
      {
        'categoryId': 1,
        'questionId': 4,
        'answer': diabetesComplication
      }, // Question 4
      {
        'categoryId': 1,
        'questionId': 5,
        'answer': hypertensionComplication
      }, // Question 5
      {'categoryId': 1, 'questionId': 6, 'answer': hadCSection}, // Question 6
    ];

    try {
      final response = await http.post(
        Uri.parse("${Urils.Url}/Eeruyir/Categoriesanswer.php"),
        headers: {'Content-Type': 'application/json'},
        body: json
            .encode({'patientId': widget.patientId, 'responses': responses}),
      );

      final result = json.decode(response.body);

      if (response.statusCode == 200) {
        showAlert('Success',
            'Patient details saved successfully. Patient ID: ${result['patientId']}');
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                ObstetricScreen1(patientId: result['patientId']),
          ),
        );
      } else {
        showAlert("Error", result['message'] ?? 'Failed to submit data');
      }
    } catch (error) {
      showAlert("Error", "Failed to submit data");
      print("Error submitting data: $error");
    }
  }

  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK')),
        ],
      ),
    );
  }

  // You can add a method to build a question as before, but now with these new questions.
  Widget buildQuestion(String question, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(question, style: const TextStyle(fontSize: 16)),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('Yes'),
                value: 'yes',
                groupValue: (question ==
                        'Are you experiencing APH in current pregnancy? (Bleeding from the vagina after 20 weeks and before labour)')
                    ? cervicalIncompetence
                    : (question ==
                            'Does your ECHO findings suggest Heart disease in current pregnancy?')
                        ? heartDisease
                        : (question ==
                                'Is this a Multiple Pregnancy (twins or triplets)?')
                            ? multiplePregnancy
                            : (question ==
                                    'Diabetes complicating pregnancy (first time diagnosed with increased sugar level or currently on any medication for diabetes)')
                                ? diabetesComplication
                                : (question ==
                                        'Does Hypertension complicating pregnancy?')
                                    ? hypertensionComplication
                                    : (question ==
                                            'Have you had C-section in your previous pregnancy?')
                                        ? hadCSection
                                        : '',
                onChanged: onChanged,
              ),
            ),
            Expanded(
              child: RadioListTile<String?>(
                title: const Text('No'),
                value: 'no',
                groupValue: (question ==
                        'Are you experiencing APH in current pregnancy? (Bleeding from the vagina after 20 weeks and before labour)')
                    ? cervicalIncompetence
                    : (question ==
                            'Does your ECHO findings suggest Heart disease in current pregnancy?')
                        ? heartDisease
                        : (question ==
                                'Is this a Multiple Pregnancy (twins or triplets)?')
                            ? multiplePregnancy
                            : (question ==
                                    'Diabetes complicating pregnancy (first time diagnosed with increased sugar level or currently on any medication for diabetes)')
                                ? diabetesComplication
                                : (question ==
                                        'Does Hypertension complicating pregnancy?')
                                    ? hypertensionComplication
                                    : (question ==
                                            'Have you had C-section in your previous pregnancy?')
                                        ? hadCSection
                                        : '',
                onChanged: onChanged,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Obstetric History',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        automaticallyImplyLeading: false,
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildQuestion(
                    'Are you experiencing APH in current pregnancy? (Bleeding from the vagina after 20 weeks and before labour)',
                    (value) =>
                        setState(() => cervicalIncompetence = value ?? '')),
                buildQuestion(
                    'Does your ECHO findings suggest Heart disease in current pregnancy?',
                    (value) => setState(() => heartDisease = value ?? '')),
                buildQuestion(
                    'Is this a Multiple Pregnancy (twins or triplets)?',
                    (value) => setState(() => multiplePregnancy = value ?? '')),
                buildQuestion(
                    'Diabetes complicating pregnancy (first time diagnosed with increased sugar level or currently on any medication for diabetes)',
                    (value) =>
                        setState(() => diabetesComplication = value ?? '')),
                buildQuestion(
                    'Does Hypertension complicating pregnancy?',
                    (value) =>
                        setState(() => hypertensionComplication = value ?? '')),
                buildQuestion(
                    'Have you had C-section in your previous pregnancy?',
                    (value) => setState(() => hadCSection = value ?? '')),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 30),
                    textStyle: const TextStyle(fontSize: 16),
                  ),
                  onPressed: handleSubmit,
                  child: const Text('Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
