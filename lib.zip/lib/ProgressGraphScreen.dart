import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/uril.dart';

class ProgressGraphScreen extends StatefulWidget {
  final String patientId;
  final String trimester;

  const ProgressGraphScreen({
    Key? key,
    required this.patientId,
    required this.trimester,
  }) : super(key: key);

  @override
  State<ProgressGraphScreen> createState() => _ProgressGraphScreenState();
}

class _ProgressGraphScreenState extends State<ProgressGraphScreen> {
  late Future<List<Map<String, dynamic>>> _progressData;

  @override
  void initState() {
    super.initState();
    _progressData = fetchProgressData(widget.patientId, widget.trimester);
  }

  // Fetching the data from the backend
  Future<List<Map<String, dynamic>>> fetchProgressData(
      String patientId, String trimester) async {
    try {
      final Map<String, String> body = {
        'patient_id': patientId,
        'trimester': trimester,
      };

      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/progress.php'),
        body: body,
      );

      if (response.statusCode == 200) {
        final List<dynamic> result = jsonDecode(response.body);
        return result
            .map((item) => {
                  'completion_date': item['completion_date'],
                  'total_videos_completed': item['total_videos_completed'],
                  'total_videos': item['total_videos']
                })
            .toList();
      } else {
        throw Exception('Failed to fetch progress data');
      }
    } catch (error) {
      print('Error fetching progress data: $error');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Progress Graph',
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF007DFE),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _progressData,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final data = snapshot.data ?? [];
          if (data.isEmpty) {
            return const Center(child: Text('No data available.'));
          }

          // Prepare data for the graph
          final List<FlSpot> completedSpots = [];
          final List<FlSpot> totalSpots = [];

          double totalVideos = 0; // Store the total_videos for maxY

          for (int i = 0; i < data.length; i++) {
            final double completed =
                double.tryParse(data[i]['total_videos_completed'].toString()) ??
                    0.0;
            totalVideos = double.tryParse(data[i]['total_videos'].toString()) ??
                0.0; // Set total_videos to the last value

            completedSpots.add(FlSpot(i.toDouble(), completed));
            totalSpots.add(FlSpot(i.toDouble(), totalVideos));
          }

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: LineChart(
              LineChartData(
                lineBarsData: [
                  LineChartBarData(
                    spots: completedSpots,
                    isCurved: true,
                    gradient: const LinearGradient(
                      colors: [Colors.blue, Colors.lightBlueAccent],
                    ),
                    belowBarData: BarAreaData(show: false),
                  ),
                  // LineChartBarData(
                  //   spots: totalSpots,
                  //   isCurved: true,
                  //   gradient: const LinearGradient(
                  //     colors: [Colors.green, Colors.lightGreenAccent],
                  //   ),
                  //   belowBarData: BarAreaData(show: false),
                  // ),
                ],
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toString(),
                          style: const TextStyle(fontSize: 10),
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: false, // Hide bottom titles (date)
                    ),
                  ),
                ),
                minY: 0, // Start from 0 on Y-axis
                maxY: totalVideos, // Set maxY to total_videos from the dataset
                borderData: FlBorderData(
                  show: true,
                  border: Border.all(color: Colors.grey),
                ),
                gridData: FlGridData(
                  show: true,
                  verticalInterval:
                      1, // Set the interval for grid lines (X-axis)
                  horizontalInterval:
                      1, // Set the interval for grid lines (Y-axis)
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
