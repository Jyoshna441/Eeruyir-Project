import 'dart:async';

import 'package:Eeruyir/SelectionScreen.dart';
import 'package:flutter/material.dart';
import 'dart:convert'; // For JSON decoding
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:Eeruyir/BabyKickCountScreen.dart';
import 'package:Eeruyir/BumpGalleryScreen.dart';
import 'package:Eeruyir/MonthQuestion.dart';
import 'package:Eeruyir/PatientLoginScreen.dart';
import 'package:Eeruyir/PatientProfile.dart';
import 'package:Eeruyir/ProgressGraphScreen.dart';
import 'package:Eeruyir/VideoRecommendations.dart';
import 'package:Eeruyir/OutcomeOfDeliveryScreen.dart';
import 'package:Eeruyir/DangerSignsScreen.dart';
import 'package:Eeruyir/NotificationsScreen.dart';
import 'package:Eeruyir/uril.dart';
import 'package:shared_preferences/shared_preferences.dart';

// For MonthQuestion screen

class PatientDashboard extends StatefulWidget {
  final String patientId;

  const PatientDashboard({super.key, required this.patientId});

  @override
  _PatientDashboardState createState() => _PatientDashboardState();
}

class _PatientDashboardState extends State<PatientDashboard>
    with SingleTickerProviderStateMixin {
  String trimester = 'Loading...';
  String weeks = '';
  String months = '';
  String days = '';
  int weeksPregnant = 0;
  int notificationCount = 0;
  int monthsPregnant = 0;
  Map<String, dynamic>? alertData;
  String? imagePath;
  bool isLoading = false;

  late AnimationController _controller;
  late Animation<double> opacityAnim;
  late Animation<Offset> translateYAnim;
  bool menuVisible = false;
  late ScrollController _horizontalScrollController;
  Timer? _horizontalScrollTimer;

  @override
  void initState() {
    super.initState();

    // Initialize the AnimationController
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    // Initialize the opacity and translation animations
    opacityAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeIn),
    );

    translateYAnim =
        Tween<Offset>(begin: const Offset(0, -1), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    fetchLmpDate();
    fetchAlert();
    fetchNotificationCount();
    _horizontalScrollController = ScrollController();
    startHorizontalAutoScroll();
  }

  void startHorizontalAutoScroll() {
    _horizontalScrollTimer =
        Timer.periodic(const Duration(seconds: 2), (timer) {
      if (_horizontalScrollController.hasClients) {
        final maxScroll = _horizontalScrollController.position.maxScrollExtent;
        final currentScroll = _horizontalScrollController.offset;

        // Scroll forward by 100 pixels, or reset if at the end
        double newScrollPosition = currentScroll + 100;
        if (newScrollPosition >= maxScroll) {
          newScrollPosition = 0; // Reset to the beginning
        }
        _horizontalScrollController.animateTo(
          newScrollPosition,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  void toggleMenu() {
    if (menuVisible) {
      _controller.reverse();
    } else {
      _controller.forward();
    }
    setState(() {
      menuVisible = !menuVisible;
    });
  }

  @override
  @override
  void dispose() {
    _controller.dispose();
    _horizontalScrollTimer?.cancel();
    _horizontalScrollController.dispose();
    super.dispose();
  }

  void calculateTrimester(String lmpDate) {
    DateTime lmp = DateTime.parse(lmpDate);
    DateTime today = DateTime.now();
    int diffDays = today.difference(lmp).inDays;
    weeksPregnant = (diffDays / 7).floor();
    monthsPregnant = (weeksPregnant / 4).floor();
    int daysPregnant = diffDays % 7;

    setState(() {
      weeks = '$weeksPregnant weeks';
      months = '$monthsPregnant months';

      days = '$daysPregnant days';
      if (weeksPregnant >= 0 && weeksPregnant <= 12) {
        trimester = '1st Trimester';
      } else if (weeksPregnant >= 13 && weeksPregnant <= 27) {
        trimester = '2nd Trimester';
      } else if (weeksPregnant >= 28 && weeksPregnant <= 40) {
        trimester = '3rd Trimester';
      } else {
        trimester = 'Out of Range';
      }
    });
    fetchAlert();
  }

  Future<void> fetchLmpDate() async {
    try {
      final url = Uri.parse(
          '${Urils.Url}/Eeruyir/patientmetric.php?patientId=${widget.patientId}');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final status = data['status'];
        final lmpDate = data['lmpDate'];

        if (status == 'success' && lmpDate != null) {
          calculateTrimester(lmpDate);
        } else {
          setState(() {
            trimester = 'No Data';
          });
          showAlert(
              'No Data',
              data['message'] ??
                  'LMP Date not found for the given patient ID.');
        }
      } else {
        showAlert('Error', 'Failed to fetch LMP Date. Please try again.');
      }
    } catch (e) {
      showAlert('Error', 'An error occurred. Please try again.');
    }
  }

  // Future<void> fetchAlert() async {
  //   print('Fetching alerts for patient ID: ${widget.patientId}');
  //   print('Fetching alerts for patient ID: $weeksPregnant');
  //   print('Fetching alerts for patient ID: $monthsPregnant');
  //   setState(() {
  //     isLoading = true;
  //   });

  //   try {
  //     final response = await http.post(
  //       Uri.parse('${Urils.Url}/Eeruyir/get_alert.php'),
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode({
  //         'patient_id': widget.patientId,
  //         'month': monthsPregnant,
  //       }),
  //     );
  //     print('Response status: ${response.statusCode}');

  //     final jsonResponse = jsonDecode(response.body);
  //     print('API Response: $jsonResponse');

  //     if (jsonResponse['error'] != null) {
  //       showErrorAlert(jsonResponse['error']);
  //     } else if (jsonResponse['message'] != 'Alert acknowledged.' &&
  //         jsonResponse['message'] != 'No alert found for the provided month.') {
  //       alertData = jsonResponse;

  //       bool canShowAlert = await shouldShowAlert();
  //       if (canShowAlert) {
  //         showAlertDialog(jsonResponse);
  //       }

  //     }
  //   } catch (error) {
  //     showErrorAlert('Failed to fetch alerts. Please try again.');
  //   } finally {
  //     setState(() {
  //       isLoading = false;
  //     });
  //   }
  // }

  Future<void> fetchAlert() async {
    print('Fetching alerts for patient ID: ${widget.patientId}');
    print('Fetching alerts for patient ID: $weeksPregnant');
    print('Fetching alerts for patient ID: $monthsPregnant');
    setState(() {
      isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/get_alert.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'patient_id': widget.patientId,
          'month': monthsPregnant,
        }),
      );
      print('Response status: ${response.statusCode}');

      final jsonResponse = jsonDecode(response.body);
      print('API Response: $jsonResponse');

      // Check if the alert has an 'acknowledged' field, and skip displaying if acknowledged
      if (jsonResponse['acknowledged'] == true) {
        print('Alert has already been acknowledged.');
        return;
      }

      if (jsonResponse['error'] != null) {
        showErrorAlert(jsonResponse['error']);
      } else if (jsonResponse['message'] != 'Alert acknowledged.' &&
          jsonResponse['message'] != 'No alert found for the provided month.') {
        alertData = jsonResponse;

        bool canShowAlert = await shouldShowAlert();
        if (canShowAlert) {
          showAlertDialog(jsonResponse);
        }
      }
    } catch (error) {
      showErrorAlert('Failed to fetch alerts. Please try again.');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> handleDoneTests(String alertId) async {
    final picker = ImagePicker();

    try {
      // Open the camera directly without checking for permissions
      final pickedFile = await picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 100,
        preferredCameraDevice: CameraDevice.rear,
      );

      if (pickedFile != null) {
        setState(() {
          imagePath = pickedFile.path;
        });

        await uploadSelectedImage(pickedFile.path, widget.patientId, alertId);
      } else {
        print('Image capture was canceled');
      }
    } catch (e) {
      showErrorAlert('Error accessing the camera: ${e.toString()}');
    }
  }

  Future<void> uploadSelectedImage(
      String imageUri, String patientId, String alertId) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('${Urils.Url}/Eeruyir/scan.php'),
    );

    request.fields['patient_id'] = patientId;
    request.fields['alert_id'] = alertId;
    request.fields['months'] = monthsPregnant.toString();
    request.files.add(await http.MultipartFile.fromPath('scanImage', imageUri));

    try {
      final response = await request.send();
      final responseData = await http.Response.fromStream(response);

      final result = jsonDecode(responseData.body);
      if (response.statusCode == 200) {
        showSuccessAlert(result['message']);
      } else {
        showErrorAlert(result['message']);
      }
    } catch (error) {
      showErrorAlert('Failed to upload image. Please try again.');
    }
  }

  Future<void> handleDontRemind() async {
    print("handleDontRemind function has been called"); // Confirm function call

    WidgetsBinding.instance.addPostFrameCallback((_) {
      showDialog(
        context: context, // Ensure context is available
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Reminder'),
            content: const Text(
                'Please do the testings and consult the doctor as soon as possible.'),
            actions: [
              TextButton(
                onPressed: () async {
                  try {
                    print("Setting reminderTimestamp in SharedPreferences");
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.setInt(
                      'reminderTimestamp',
                      DateTime.now().millisecondsSinceEpoch,
                    );
                    print("reminderTimestamp set successfully");
                  } catch (e) {
                    print("Error setting reminderTimestamp: $e");
                  }
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    });
  }

  Future<bool> shouldShowAlert() async {
    final prefs = await SharedPreferences.getInstance();
    final lastReminder = prefs.getInt('reminderTimestamp');

    if (lastReminder != null) {
      final now = DateTime.now().millisecondsSinceEpoch;
      if (now - lastReminder < 24 * 60 * 60 * 1000) {
        return false;
      }
    }
    return true;
  }

  void showAlertDialog(Map<String, dynamic> data, {VoidCallback? onConfirm}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('New Alert!'),
        content: Text(
          'Message: ${data['id']}\n'
          'Message: ${data['alert_message']}\n'
          'Tests Required: ${data['tests_required']}\n'
          'Scan Required: ${data['scan_required']}',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              handleDoneTests(data['id'].toString());
            },
            child: const Text('Yes'),
          ),
          TextButton(
            onPressed: () async {
              try {
                print('No button pressed');
                await handleDontRemind(); // Call the function here
              } catch (e) {
                print('Error in handleDontRemind: $e');
              }
              Navigator.pop(context);
            },
            child: const Text('No'),
          ),
        ],
      ),
    );
  }

  void showSuccessAlert(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Success'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void showErrorAlert(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> fetchNotificationCount() async {
    try {
      final response = await http.get(
        Uri.parse(
            '${Urils.Url}/Eeruyir/get_notification_count.php?patient_id=${widget.patientId}'),
        headers: {'Content-Type': 'application/json'},
      );

      final data = json.decode(response.body);

      if (data['status'] == 'success') {
        setState(() {
          notificationCount = data['notification_count'];
        });
      } else {
        setState(() {
          notificationCount = 0;
        });
        print('Error: ${data['message']}');
      }
    } catch (error) {
      print('Error fetching notification count: $error');
    }
  }

  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              child: const Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  // Widget buildImageCard(String imagePath) {
  //   return Card(
  //     child: Image.asset(imagePath),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: menuVisible ? () => toggleMenu() : null,
        child: Stack(
          children: [
            Column(
              children: [
                // Header
                Container(
                  // Adjusted padding to fine-tune the spacing around the header content
                  padding: const EdgeInsets.fromLTRB(20, 40, 20, 20),
                  color: const Color(
                      0xFF007DFE), // Background color for the header
                  child: Column(
                    children: [
                      Row(
                        // Space out the menu button and the right-side elements (profile and notifications)
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            // Menu button with an icon
                            icon: const Icon(Icons.menu,
                                color: Colors.white, size: 30),
                            onPressed:
                                toggleMenu, // Toggles the visibility of the menu
                          ),
                          Row(
                            children: [
                              GestureDetector(
                                // Redirects to the Patient Profile screen when tapped
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => PatientProfile(
                                        patientId: widget
                                            .patientId, // Passes patient ID
                                      ),
                                    ),
                                  );
                                },
                                child: Container(
                                  // Styles the profile icon container
                                  decoration: BoxDecoration(
                                    shape: BoxShape
                                        .circle, // Circular shape for the profile icon
                                    color: Colors
                                        .white, // Background color for the icon
                                  ),
                                  padding: const EdgeInsets.all(
                                      6), // Padding for better spacing
                                  child: const Icon(
                                    Icons
                                        .person, // Icon representing a patient profile
                                    color: Colors.blue, // Icon color
                                    size: 24, // Adjust icon size as needed
                                  ),
                                ),
                              ),
                              const SizedBox(
                                  width:
                                      25), // Adds spacing between profile and notification icon
                              GestureDetector(
                                // Opens the Notifications screen when tapped
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => NotificationsScreen(
                                        patientId: widget
                                            .patientId, // Passes patient ID
                                      ),
                                    ),
                                  );
                                  fetchNotificationCount(); // Refreshes the notification count after returning
                                },
                                child: Stack(
                                  clipBehavior: Clip
                                      .none, // Allows the badge to overflow outside the Stack
                                  alignment: Alignment
                                      .center, // Center aligns the main icon
                                  children: [
                                    const Icon(
                                      Icons.notifications,
                                      color: Colors
                                          .white, // Notification icon color
                                      size: 28, // Adjust size as needed
                                    ),
                                    if (notificationCount >
                                        0) // Display badge only if notifications exist
                                      Positioned(
                                        right:
                                            -4, // Moves the badge slightly outside the top-right corner
                                        top:
                                            -4, // Moves the badge slightly above the icon
                                        child: Container(
                                          // Notification badge styling
                                          padding: const EdgeInsets.all(4),
                                          decoration: const BoxDecoration(
                                            color: Colors
                                                .red, // Badge background color
                                            shape: BoxShape
                                                .circle, // Circular badge
                                          ),
                                          constraints: const BoxConstraints(
                                            minWidth:
                                                20, // Minimum width to ensure consistent badge size
                                            minHeight:
                                                20, // Minimum height for consistent badge size
                                          ),
                                          child: Center(
                                            child: Text(
                                              '$notificationCount', // Notification count
                                              style: const TextStyle(
                                                color:
                                                    Colors.white, // Text color
                                                fontSize: 12, // Font size
                                                fontWeight: FontWeight
                                                    .bold, // Bold font for better visibility
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Content
                Expanded(
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 25),
                          SizedBox(
                            height: 200,
                            child: ListView(
                              controller: _horizontalScrollController,
                              scrollDirection: Axis.horizontal,
                              children: [
                                buildImageCard('assets/dp12.png'),
                                buildImageCard('assets/dp4.png'),
                                buildImageCard('assets/dp7.png'),
                                buildImageCard('assets/dp10.png'),
                                buildImageCard('assets/dp11.png'),
                                buildImageCard('assets/dp13.png'),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            "Pregnancy Metrics",
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              buildMetricCard("Trimester", trimester),
                              buildMetricCard("Month", months),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              buildMetricCard("Week", weeks),
                              buildMetricCard("Day", days),
                            ],
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            "Pregnancy Tools",
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              buildToolCard(
                                  "Monthly Reminder", Icons.calendar_today, () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => MonthQuestion(
                                        patientId: widget.patientId),
                                  ),
                                );
                              }),
                              buildToolCard(
                                  "Exercise Progress", Icons.fitness_center,
                                  () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ProgressGraphScreen(
                                      patientId: widget.patientId,
                                      trimester: trimester,
                                    ),
                                  ),
                                );
                              }),
                              buildToolCard(
                                  "Recommended Videos", Icons.video_collection,
                                  () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => VideoRecommendations(
                                      patientId: widget.patientId,
                                      trimester: trimester,
                                    ),
                                  ),
                                );
                              }),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              buildToolCard(
                                  "Outcome of Delivery", Icons.pregnant_woman,
                                  () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        OutcomeOfDeliveryScreen(
                                            patientId: widget.patientId),
                                  ),
                                );
                              }),
                              buildToolCard(
                                  "Baby Kickcount", Icons.child_friendly, () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BabyKickCountScreen(
                                      patientId: widget.patientId,
                                      weeks: weeksPregnant,
                                    ),
                                  ),
                                );
                              }),
                              buildToolCard("Danger Signs", Icons.warning, () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          DangerSignsScreen()),
                                );
                              }),
                            ],
                          ),

                          // Row(
                          //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          //   children: [
                          //     buildToolCard(
                          //         "Bump Gallery", Icons.pregnant_woman, () {
                          //       Navigator.push(
                          //         context,
                          //         MaterialPageRoute(
                          //             builder: (context) => BumpGalleryScreen(
                          //                 patientId: widget.patientId)),
                          //       );
                          //     }),
                          //   ],
                          // ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),

            // Overlay menu
            if (menuVisible)
              Positioned.fill(
                child: GestureDetector(
                  onTap: toggleMenu,
                  child: Container(
                    color: Colors.black54,
                    child: SlideTransition(
                      position: translateYAnim,
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.8,
                          color: Colors.white,
                          child: Column(
                            children: [
                              Container(
                                color: const Color(0xFF007DFE),
                                height: 100.0,
                                child: const Center(
                                  child: Text(
                                    'Eeruyir',
                                    style: TextStyle(
                                      fontSize: 24,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              const Divider(height: 20, thickness: 2),
                              MenuItem(
                                title: 'Monthly Remainder',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => MonthQuestion(
                                        patientId: widget.patientId),
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Exercise Progress',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ProgressGraphScreen(
                                      patientId: widget.patientId,
                                      trimester: trimester,
                                    ),
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Recommended Videos',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => VideoRecommendations(
                                      patientId: widget.patientId,
                                      trimester: trimester,
                                    ),
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Outcome of Delivery',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        OutcomeOfDeliveryScreen(
                                            patientId: widget.patientId),
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Baby Kickcount',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BabyKickCountScreen(
                                      patientId: widget.patientId,
                                      weeks: weeksPregnant,
                                    ),
                                  ),
                                ),
                              ),
                              MenuItem(
                                title: 'Danger Signs',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          DangerSignsScreen()),
                                ),
                              ),
                              const Divider(
                                height: 20, // Adds spacing around the divider
                                thickness: 2, // Thickness of the divider
                              ),
                              MenuItem(
                                title: 'Logout',
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const SelectionScreen(), // Directly calling the class
                                  ),
                                ),
                              ),
                              // MenuItem(
                              //   title: 'Bump Gallery',
                              //   onTap: () => Navigator.push(
                              //     context,
                              //     MaterialPageRoute(
                              //         builder: (context) => BumpGalleryScreen(
                              //             patientId: widget.patientId)),
                              //   ),
                              // ),

                              // Add additional menu items as needed...
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget buildImageCard(String imagePath) {
    return Container(
      width: 300, // Increased width for larger images
      margin: const EdgeInsets.only(right: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.asset(
          imagePath,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  Widget buildMetricCard(String title, String value) {
    return Container(
      width: 150,
      height: 60,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 14, color: Colors.grey),
          ),
          Text(
            value,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget buildToolCard(String title, IconData icon, VoidCallback? onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.grey),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class MenuItem extends StatelessWidget {
  final String title;
  final Function onTap;

  const MenuItem({super.key, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(title),
      onTap: () => onTap(),
    );
  }
}
