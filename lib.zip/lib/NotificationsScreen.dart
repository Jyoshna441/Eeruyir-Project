import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:Eeruyir/uril.dart';

class NotificationsScreen extends StatefulWidget {
  final String patientId;

  const NotificationsScreen({super.key, required this.patientId});

  @override
  _NotificationsScreenState createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  bool _isLoading = false;
  List<dynamic> _notifications = [];

  @override
  void initState() {
    super.initState();
    _fetchNotifications(); // Fetch notifications when the screen is initialized
  }

  Future<void> _fetchNotifications() async {
    setState(() {
      _isLoading = true; // Start loading
    });

    if (widget.patientId.isEmpty) {
      print('Patient ID is required.');
      setState(() {
        _isLoading = false;
      });
      return; // Exit if patient_id is not defined
    }

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/get_alerting.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'patient_id': widget.patientId}),
      );

      final data = json.decode(response.body);
      print('Response data: $data');

      if (data['success']) {
        setState(() {
          _notifications = data['alerts'];
        });
      } else {
        setState(() {
          _notifications = []; // Set empty array if no alerts found
        });
      }
    } catch (error) {
      print('Error fetching notifications: $error');
    } finally {
      setState(() {
        _isLoading = false; // Stop loading
      });
    }
  }

  Future<void> _handleNotificationFollow(int id) async {
    if (id == 0 || widget.patientId.isEmpty) {
      print('Both Notification ID and Patient ID are required.');
      return; // Exit if either ID is not defined
    }

    try {
      final response = await http.post(
        Uri.parse('${Urils.Url}/Eeruyir/resolve_alert.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'alert_id': id, 'patient_id': widget.patientId}),
      );

      final data = json.decode(response.body);

      if (data['success']) {
        setState(() {
          _notifications
              .removeWhere((notification) => notification['alert_id'] == id);
        });
      } else {
        print('Error resolving notification: ${data['message']}');
      }
    } catch (error) {
      print('Error resolving notification: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchNotifications, // Reload notifications
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _notifications.isEmpty
              ? const Center(child: Text('No notifications available.'))
              : ListView.builder(
                  itemCount: _notifications.length,
                  itemBuilder: (context, index) {
                    final notification = _notifications[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 16),
                      elevation: 2,
                      child: ListTile(
                        // Display only the alert message
                        title: Text(notification['alert_message'] ??
                            'No message'), // Changed to alert_message
                        subtitle: null, // No subtitle needed
                        trailing: IconButton(
                          icon: const Icon(Icons.check),
                          onPressed: () => _handleNotificationFollow(
                              notification['alert_id']),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
